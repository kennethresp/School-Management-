Public Class Addnewsubject
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtsubname As System.Windows.Forms.TextBox
    Friend WithEvents txtsubid As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbclassname As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnadd = New System.Windows.Forms.Button
        Me.txtsubname = New System.Windows.Forms.TextBox
        Me.txtsubid = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbclassname = New System.Windows.Forms.ComboBox
        Me.SuspendLayout()
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(303, 80)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.TabIndex = 9
        Me.btnadd.Text = "Add"
        '
        'txtsubname
        '
        Me.txtsubname.Location = New System.Drawing.Point(135, 80)
        Me.txtsubname.Name = "txtsubname"
        Me.txtsubname.Size = New System.Drawing.Size(144, 20)
        Me.txtsubname.TabIndex = 8
        Me.txtsubname.Text = ""
        '
        'txtsubid
        '
        Me.txtsubid.Location = New System.Drawing.Point(135, 48)
        Me.txtsubid.MaxLength = 4
        Me.txtsubid.Name = "txtsubid"
        Me.txtsubid.Size = New System.Drawing.Size(72, 20)
        Me.txtsubid.TabIndex = 7
        Me.txtsubid.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 23)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Enter Subject Name :"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Enter Subject ID :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 23)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Select Class Name :"
        '
        'cmbclassname
        '
        Me.cmbclassname.Location = New System.Drawing.Point(135, 16)
        Me.cmbclassname.Name = "cmbclassname"
        Me.cmbclassname.Size = New System.Drawing.Size(145, 21)
        Me.cmbclassname.TabIndex = 11
        Me.cmbclassname.Text = "ComboBox1"
        '
        'Addnewsubject
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 118)
        Me.Controls.Add(Me.cmbclassname)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.txtsubname)
        Me.Controls.Add(Me.txtsubid)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Addnewsubject"
        Me.Text = "Addnewsubject"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim cclass As New clsschmngt("tblclass")
    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtsubid.Text = "" Then
            MsgBox("Plz input classid..", MsgBoxStyle.Information)
            txtsubid.Focus()
        ElseIf txtsubname.Text = "" Then
            MsgBox("Plz input classname..", MsgBoxStyle.Information)
            txtsubname.Focus()
        Else
            Dim squery As String = "Insert into tblsubject values (" + cmbclassname.SelectedValue.ToString + ",'" + txtsubid.Text.ToString & "','" + txtsubname.Text + "')"
            Dim addclass As New clsschmngt("tblsubject", squery)
            addclass.save("Record Saved Successfully...")
            txtsubid.Text = ""
            txtsubname.Text = ""
        End If
    End Sub

    Private Sub Addnewsubject_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        badds = True
        cmbclassname.DataSource = cclass.dt
        cmbclassname.DisplayMember = "className"
        cmbclassname.ValueMember = "classid"
    End Sub

    Private Sub txtsubid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsubid.KeyPress
        If Char.IsLetter(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class

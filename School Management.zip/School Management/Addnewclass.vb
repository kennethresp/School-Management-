Public Class Addnewclass
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtclassid As System.Windows.Forms.TextBox
    Friend WithEvents txtclassname As System.Windows.Forms.TextBox
    Friend WithEvents btnadd As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtclassid = New System.Windows.Forms.TextBox
        Me.txtclassname = New System.Windows.Forms.TextBox
        Me.btnadd = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Class ID :"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter Class Name :"
        '
        'txtclassid
        '
        Me.txtclassid.Location = New System.Drawing.Point(144, 16)
        Me.txtclassid.MaxLength = 4
        Me.txtclassid.Name = "txtclassid"
        Me.txtclassid.Size = New System.Drawing.Size(72, 20)
        Me.txtclassid.TabIndex = 2
        Me.txtclassid.Text = ""
        '
        'txtclassname
        '
        Me.txtclassname.Location = New System.Drawing.Point(144, 48)
        Me.txtclassname.Name = "txtclassname"
        Me.txtclassname.Size = New System.Drawing.Size(144, 20)
        Me.txtclassname.TabIndex = 3
        Me.txtclassname.Text = ""
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(312, 48)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.TabIndex = 4
        Me.btnadd.Text = "Add"
        '
        'Addnewclass
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 86)
        Me.Controls.Add(Me.btnadd)
        Me.Controls.Add(Me.txtclassname)
        Me.Controls.Add(Me.txtclassid)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Addnewclass"
        Me.Text = "Addnewclass"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtclassid.Text = "" Then
            MsgBox("Plz input classid..", MsgBoxStyle.Information)
            txtclassid.Focus()
        ElseIf txtclassname.Text = "" Then
            MsgBox("Plz input classname..", MsgBoxStyle.Information)
            txtclassname.Focus()
        Else
            Dim squery As String = "Insert into tblclass values ('" + txtclassid.Text.ToString & "','" + txtclassname.Text + "')"
            Dim addclass As New clsschmngt("tblclass", squery)
            addclass.save("Record Saved Successfully...")
            txtclassid.Text = ""
            txtclassname.Text = ""


        End If
    End Sub

    Private Sub txtclassid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtclassid.KeyPress
        If Char.IsLetter(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Addnewclass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        baddc = True
    End Sub

    Private Sub Addnewclass_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        baddc = False
    End Sub

   
End Class

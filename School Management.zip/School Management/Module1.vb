Imports System.Data.OleDb
Module Module1
    Public mdlabout As Aboutus
    Public babout As Boolean = False
    Public mdllevel As Frmnewclass
    Public blevel As Boolean = False
    Public mdllogind As Login_Details
    Public blogind As Boolean = False
    Public mdllogin As Login
    Public blogin As Boolean = False
    Public mdladdschyear As Add_School_Year
    Public bmodify As Boolean = False
    Public mdlmstudr As Modify_Student_Records
    Public bmstudr As Boolean = False
    Public mdlschool As School_Info
    Public bschool As Boolean = False
    Public mdlsearch As Search
    Public bsearch As Boolean = False
    Public mdlsection As Section
    Public bsection As Boolean = False
    Public mdlstudrec As Students_Records
    Public bstudrec As Boolean = False
    Public mdluserrec As User_Records
    Public buserrec As Boolean = False
    Public mdlviewy As View_year
    Public bviewy As Boolean = False
    Public mdlviewstud As Viewstudentoption
    Public bviewstud As Boolean = False
    Public bclndr As Boolean = False
    Public bcalendar As Calender
    Public mdltran As transaction
    Public btran As Boolean = False
    Public mdlbooks As books
    Public bbooks As Boolean = False
    Public mdlstud As students
    Public bstud As Boolean = False
    Public mdlreport As report
    Public breport As Boolean = False
    Public mdlchangepass As change_pass
    Public bchangepass As Boolean = False
    Public baddc As Boolean = False
    Public badds As Boolean = False
    Public mdlfee_s As feesschedule
    Public bfee_s As Boolean = False
    Public schyear As String
    Sub main()
        Dim frmmain As Form1
        frmmain.Show()
    End Sub


    Public Class fillreader
        Public Function readrdr(ByVal tblname As String, ByVal conn As OleDb.OleDbConnection, ByVal lv As ListView, ByVal tblitem As String) As String
            Try
                Dim cmd As New OleDb.OleDbCommand("Select * from " + tblname, conn)
                conn.Close()
                conn.Open()
                Dim rdr As OleDb.OleDbDataReader = cmd.ExecuteReader
                While rdr.Read
                    lv.Items.Add(rdr(tblitem))
                End While
                conn.Close()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End Function
    End Class
    Public constr As String = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" & My.Application.Info.DirectoryPath & "/raj.mdb"
    Public conn As New OleDb.OleDbConnection(constr)
End Module

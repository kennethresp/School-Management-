Public Class Modify_Student_Records
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Public WithEvents txtParentsAddress As System.Windows.Forms.TextBox
    Public WithEvents txtMName As System.Windows.Forms.TextBox
    Public WithEvents txtMOccupation As System.Windows.Forms.TextBox
    Public WithEvents txtFName As System.Windows.Forms.TextBox
    Public WithEvents txtFOccupation As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Public WithEvents dtpDateEnrolled As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtstudname As System.Windows.Forms.TextBox
    Friend WithEvents txtenrollno As System.Windows.Forms.TextBox
    Friend WithEvents btnphoto As System.Windows.Forms.Button
    Friend WithEvents picphoto As System.Windows.Forms.PictureBox
    Friend WithEvents txtage As System.Windows.Forms.TextBox
    Friend WithEvents cmbgender As System.Windows.Forms.ComboBox
    Friend WithEvents dtpdob As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtaddress As System.Windows.Forms.TextBox
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Public WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents cmbsubject As System.Windows.Forms.ComboBox
    Public WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Public WithEvents txtlastSchool As System.Windows.Forms.TextBox
    Friend WithEvents lblselectedyear As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.btnphoto = New System.Windows.Forms.Button
        Me.picphoto = New System.Windows.Forms.PictureBox
        Me.txtage = New System.Windows.Forms.TextBox
        Me.cmbgender = New System.Windows.Forms.ComboBox
        Me.dtpdob = New System.Windows.Forms.DateTimePicker
        Me.txtaddress = New System.Windows.Forms.TextBox
        Me.txtstudname = New System.Windows.Forms.TextBox
        Me.txtenrollno = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtParentsAddress = New System.Windows.Forms.TextBox
        Me.txtMName = New System.Windows.Forms.TextBox
        Me.txtMOccupation = New System.Windows.Forms.TextBox
        Me.txtFName = New System.Windows.Forms.TextBox
        Me.txtFOccupation = New System.Windows.Forms.TextBox
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.cmbsubject = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.dtpDateEnrolled = New System.Windows.Forms.DateTimePicker
        Me.cmbStatus = New System.Windows.Forms.ComboBox
        Me.txtlastSchool = New System.Windows.Forms.TextBox
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btnclear = New System.Windows.Forms.Button
        Me.btncancel = New System.Windows.Forms.Button
        Me.lblselectedyear = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(464, 208)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnphoto)
        Me.TabPage1.Controls.Add(Me.picphoto)
        Me.TabPage1.Controls.Add(Me.txtage)
        Me.TabPage1.Controls.Add(Me.cmbgender)
        Me.TabPage1.Controls.Add(Me.dtpdob)
        Me.TabPage1.Controls.Add(Me.txtaddress)
        Me.TabPage1.Controls.Add(Me.txtstudname)
        Me.TabPage1.Controls.Add(Me.txtenrollno)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(456, 180)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Biodata"
        '
        'btnphoto
        '
        Me.btnphoto.Location = New System.Drawing.Point(8, 120)
        Me.btnphoto.Name = "btnphoto"
        Me.btnphoto.Size = New System.Drawing.Size(96, 24)
        Me.btnphoto.TabIndex = 13
        Me.btnphoto.Text = "Change Photo"
        '
        'picphoto
        '
        Me.picphoto.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.picphoto.Location = New System.Drawing.Point(8, 16)
        Me.picphoto.Name = "picphoto"
        Me.picphoto.Size = New System.Drawing.Size(96, 88)
        Me.picphoto.TabIndex = 12
        Me.picphoto.TabStop = False
        '
        'txtage
        '
        Me.txtage.Location = New System.Drawing.Point(368, 80)
        Me.txtage.MaxLength = 2
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(48, 21)
        Me.txtage.TabIndex = 11
        Me.txtage.Text = ""
        '
        'cmbgender
        '
        Me.cmbgender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cmbgender.Location = New System.Drawing.Point(216, 80)
        Me.cmbgender.Name = "cmbgender"
        Me.cmbgender.Size = New System.Drawing.Size(96, 23)
        Me.cmbgender.TabIndex = 10
        '
        'dtpdob
        '
        Me.dtpdob.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpdob.CustomFormat = "MMMM/dd/yyyy"
        Me.dtpdob.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpdob.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpdob.Location = New System.Drawing.Point(216, 112)
        Me.dtpdob.Name = "dtpdob"
        Me.dtpdob.Size = New System.Drawing.Size(216, 21)
        Me.dtpdob.TabIndex = 9
        Me.dtpdob.Value = New Date(2007, 2, 15, 0, 0, 0, 0)
        '
        'txtaddress
        '
        Me.txtaddress.Location = New System.Drawing.Point(216, 144)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(216, 21)
        Me.txtaddress.TabIndex = 8
        Me.txtaddress.Text = ""
        '
        'txtstudname
        '
        Me.txtstudname.Location = New System.Drawing.Point(216, 48)
        Me.txtstudname.Name = "txtstudname"
        Me.txtstudname.Size = New System.Drawing.Size(216, 21)
        Me.txtstudname.TabIndex = 7
        Me.txtstudname.Text = ""
        '
        'txtenrollno
        '
        Me.txtenrollno.Location = New System.Drawing.Point(216, 16)
        Me.txtenrollno.Name = "txtenrollno"
        Me.txtenrollno.Size = New System.Drawing.Size(216, 21)
        Me.txtenrollno.TabIndex = 6
        Me.txtenrollno.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(120, 144)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 23)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Address :"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(120, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Birth Date :"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(328, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 23)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Age :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(120, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Gender :"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(120, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Student Name :"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(120, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enroll No :"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.txtParentsAddress)
        Me.TabPage2.Controls.Add(Me.txtMName)
        Me.TabPage2.Controls.Add(Me.txtMOccupation)
        Me.TabPage2.Controls.Add(Me.txtFName)
        Me.TabPage2.Controls.Add(Me.txtFOccupation)
        Me.TabPage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(456, 180)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Family Background"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(24, 144)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(112, 24)
        Me.Label11.TabIndex = 144
        Me.Label11.Text = "Parent's Address :"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(24, 112)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 24)
        Me.Label10.TabIndex = 143
        Me.Label10.Text = "Occupation"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(24, 80)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 24)
        Me.Label9.TabIndex = 142
        Me.Label9.Text = "Mother's Name :"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(24, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 24)
        Me.Label8.TabIndex = 141
        Me.Label8.Text = "Occupation"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(24, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 24)
        Me.Label7.TabIndex = 140
        Me.Label7.Text = "Father's Name"
        '
        'txtParentsAddress
        '
        Me.txtParentsAddress.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtParentsAddress.ForeColor = System.Drawing.Color.Maroon
        Me.txtParentsAddress.Location = New System.Drawing.Point(136, 143)
        Me.txtParentsAddress.Name = "txtParentsAddress"
        Me.txtParentsAddress.Size = New System.Drawing.Size(280, 22)
        Me.txtParentsAddress.TabIndex = 139
        Me.txtParentsAddress.Text = ""
        '
        'txtMName
        '
        Me.txtMName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMName.ForeColor = System.Drawing.Color.Maroon
        Me.txtMName.Location = New System.Drawing.Point(136, 79)
        Me.txtMName.Name = "txtMName"
        Me.txtMName.Size = New System.Drawing.Size(280, 22)
        Me.txtMName.TabIndex = 137
        Me.txtMName.Text = ""
        '
        'txtMOccupation
        '
        Me.txtMOccupation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMOccupation.Location = New System.Drawing.Point(136, 111)
        Me.txtMOccupation.Name = "txtMOccupation"
        Me.txtMOccupation.Size = New System.Drawing.Size(208, 22)
        Me.txtMOccupation.TabIndex = 138
        Me.txtMOccupation.Text = ""
        '
        'txtFName
        '
        Me.txtFName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFName.ForeColor = System.Drawing.Color.Maroon
        Me.txtFName.Location = New System.Drawing.Point(136, 15)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(280, 22)
        Me.txtFName.TabIndex = 135
        Me.txtFName.Text = ""
        '
        'txtFOccupation
        '
        Me.txtFOccupation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFOccupation.Location = New System.Drawing.Point(136, 47)
        Me.txtFOccupation.Name = "txtFOccupation"
        Me.txtFOccupation.Size = New System.Drawing.Size(208, 22)
        Me.txtFOccupation.TabIndex = 136
        Me.txtFOccupation.Text = ""
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.cmbsubject)
        Me.TabPage3.Controls.Add(Me.Label14)
        Me.TabPage3.Controls.Add(Me.Label15)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.Label12)
        Me.TabPage3.Controls.Add(Me.Label13)
        Me.TabPage3.Controls.Add(Me.cmbclass)
        Me.TabPage3.Controls.Add(Me.dtpDateEnrolled)
        Me.TabPage3.Controls.Add(Me.cmbStatus)
        Me.TabPage3.Controls.Add(Me.txtlastSchool)
        Me.TabPage3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(456, 180)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "School Information"
        '
        'cmbsubject
        '
        Me.cmbsubject.Location = New System.Drawing.Point(308, 72)
        Me.cmbsubject.Name = "cmbsubject"
        Me.cmbsubject.Size = New System.Drawing.Size(136, 23)
        Me.cmbsubject.TabIndex = 143
        Me.cmbsubject.Text = "ComboBox2"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(248, 72)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(56, 23)
        Me.Label14.TabIndex = 142
        Me.Label14.Text = "Subject :"
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(40, 96)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(136, 16)
        Me.Label15.TabIndex = 141
        Me.Label15.Text = "Last School Attend :"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(40, 48)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(100, 16)
        Me.Label16.TabIndex = 140
        Me.Label16.Text = "Class  :"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(248, 24)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 23)
        Me.Label12.TabIndex = 139
        Me.Label12.Text = "Status :"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(40, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(100, 16)
        Me.Label13.TabIndex = 138
        Me.Label13.Text = "Date Enrolled :"
        '
        'cmbclass
        '
        Me.cmbclass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbclass.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbclass.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmbclass.ItemHeight = 14
        Me.cmbclass.Location = New System.Drawing.Point(36, 70)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(200, 22)
        Me.cmbclass.TabIndex = 137
        '
        'dtpDateEnrolled
        '
        Me.dtpDateEnrolled.CalendarForeColor = System.Drawing.Color.Black
        Me.dtpDateEnrolled.CalendarTitleForeColor = System.Drawing.Color.Black
        Me.dtpDateEnrolled.CustomFormat = "MMMM/dd/yyyy"
        Me.dtpDateEnrolled.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateEnrolled.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDateEnrolled.Location = New System.Drawing.Point(36, 23)
        Me.dtpDateEnrolled.Name = "dtpDateEnrolled"
        Me.dtpDateEnrolled.TabIndex = 128
        Me.dtpDateEnrolled.Value = New Date(2007, 2, 27, 0, 0, 0, 0)
        '
        'cmbStatus
        '
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbStatus.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.cmbStatus.ItemHeight = 14
        Me.cmbStatus.Items.AddRange(New Object() {"New", "Old"})
        Me.cmbStatus.Location = New System.Drawing.Point(308, 24)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(112, 22)
        Me.cmbStatus.Sorted = True
        Me.cmbStatus.TabIndex = 129
        '
        'txtlastSchool
        '
        Me.txtlastSchool.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlastSchool.ForeColor = System.Drawing.SystemColors.ControlText
        Me.txtlastSchool.Location = New System.Drawing.Point(36, 118)
        Me.txtlastSchool.Multiline = True
        Me.txtlastSchool.Name = "txtlastSchool"
        Me.txtlastSchool.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtlastSchool.Size = New System.Drawing.Size(384, 56)
        Me.txtlastSchool.TabIndex = 130
        Me.txtlastSchool.Text = ""
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(184, 216)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 24)
        Me.btnupdate.TabIndex = 1
        Me.btnupdate.Text = "Update"
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(272, 216)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 24)
        Me.btnclear.TabIndex = 2
        Me.btnclear.Text = "Clear"
        '
        'btncancel
        '
        Me.btncancel.Location = New System.Drawing.Point(360, 216)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 24)
        Me.btncancel.TabIndex = 3
        Me.btncancel.Text = "Cancel"
        '
        'lblselectedyear
        '
        Me.lblselectedyear.Location = New System.Drawing.Point(8, 216)
        Me.lblselectedyear.Name = "lblselectedyear"
        Me.lblselectedyear.Size = New System.Drawing.Size(56, 16)
        Me.lblselectedyear.TabIndex = 4
        Me.lblselectedyear.Text = "lbl"
        '
        'Modify_Student_Records
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(464, 254)
        Me.Controls.Add(Me.lblselectedyear)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Modify_Student_Records"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Modify_Student_Records"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Dim cbclass As New clsschmngt("tblclass")
    Dim cbsubject As New clsschmngt("tblsubject")
    Dim s As String
    Private Sub Modify_Student_Records_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bmstudr = True
        cmbclass.DataSource = cbclass.dt
        cmbclass.DisplayMember = "className"
        cmbclass.ValueMember = "classid"
        cmbsubject.DataSource = cbsubject.dt
        cmbsubject.DisplayMember = "subjectname"
        cmbsubject.ValueMember = "subjectid"

    End Sub

    Private Sub Modify_Student_Records_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bmstudr = False
    End Sub
    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        'schyear = lblselectedyear.Text
        Try
            Dim squery As String = "INSERT INTO tblStudentsRecords(Enrollno, Name, Gender,"
            squery += "DateOfBirth, Age, Address, FatherName, FathersOccupation,"
            squery += "MotherName, MothersOccupation, ParentAddress, SchoolLastAttend,"
            squery += "DateEnrolled, SchoolYear, Subjectid, StudentStatus, Classid)"
            squery += "VALUES"
            squery += "(" + txtenrollno.Text + ",'" + txtstudname.Text + "','" + cmbgender.Text + "',"
            squery += dtpdob.Value + "," + txtage.Text + ",'" + txtaddress.Text + "','" + txtFName.Text + "',"
            squery += "'" + txtFOccupation.Text + "','" + txtMName.Text + "','" + txtMOccupation.Text + "','" + txtParentsAddress.Text + "',"
            squery += "'" + txtlastSchool.Text + "'," + dtpDateEnrolled.Value + ",'" + schyear + "'"
            squery += "," + cmbsubject.SelectedValue.ToString + ",'" + cmbStatus.Text + "'," + cmbclass.SelectedValue.ToString + ")"
            Dim fillstudrec As New clsschmngt("tblStudentsRecords", squery)
            'MsgBox(squery)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        MsgBox("Record Added Successfully...", MsgBoxStyle.Information)
        Dim query As String = "INSERT INTO duefees(studEnrollno, studclassid, monthoffees, duefees, schoolyear) values ('" + txtenrollno.Text + "','" + cmbclass.SelectedValue.ToString + "','January'," + 1800 + "," + schyear + ")"
        Dim cbduefee As New clsschmngt("duefees", query)
    End Sub

    Private Sub dtpdob_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpdob.ValueChanged

    End Sub
End Class

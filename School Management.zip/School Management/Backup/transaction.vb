Imports System.Data.OleDb

Public Class transaction
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btn_close As System.Windows.Forms.Button
    Friend WithEvents dg_books As System.Windows.Forms.DataGrid
    Friend WithEvents lbl_retdate As System.Windows.Forms.Label
    Friend WithEvents lbl_issuedate As System.Windows.Forms.Label
    Friend WithEvents lbl_booktitle As System.Windows.Forms.Label
    Friend WithEvents lbl_bookid As System.Windows.Forms.Label
    Friend WithEvents lbl_studid As System.Windows.Forms.Label
    Friend WithEvents lbl_fine As System.Windows.Forms.Label
    Friend WithEvents lbl_fine_disp As System.Windows.Forms.Label
    Friend WithEvents Lbl_disc As System.Windows.Forms.Label
    Friend WithEvents Cmb_desc As System.Windows.Forms.ComboBox
    Friend WithEvents btn_issue As System.Windows.Forms.Button
    Friend WithEvents btn_return As System.Windows.Forms.Button
    Friend WithEvents txt_search As System.Windows.Forms.TextBox
    Friend WithEvents btn_search As System.Windows.Forms.Button
    Friend WithEvents rd_issue As System.Windows.Forms.RadioButton
    Friend WithEvents rd_return As System.Windows.Forms.RadioButton
    Friend WithEvents txt_bookid As System.Windows.Forms.TextBox
    Friend WithEvents txt_sid As System.Windows.Forms.TextBox
    Friend WithEvents lbl_studnm As System.Windows.Forms.Label
    Friend WithEvents lbl_branch As System.Windows.Forms.Label
    Friend WithEvents txt_branch As System.Windows.Forms.TextBox
    Friend WithEvents txt_sname As System.Windows.Forms.TextBox
    Friend WithEvents gb_rtn As System.Windows.Forms.GroupBox
    Friend WithEvents grb_fine As System.Windows.Forms.GroupBox
    Friend WithEvents txt_booktitle As System.Windows.Forms.TextBox
    Friend WithEvents txt_ret As System.Windows.Forms.TextBox
    Friend WithEvents txt_issue As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.gb_rtn = New System.Windows.Forms.GroupBox
        Me.txt_issue = New System.Windows.Forms.TextBox
        Me.lbl_branch = New System.Windows.Forms.Label
        Me.txt_branch = New System.Windows.Forms.TextBox
        Me.lbl_studnm = New System.Windows.Forms.Label
        Me.txt_sname = New System.Windows.Forms.TextBox
        Me.lbl_retdate = New System.Windows.Forms.Label
        Me.txt_ret = New System.Windows.Forms.TextBox
        Me.lbl_issuedate = New System.Windows.Forms.Label
        Me.lbl_booktitle = New System.Windows.Forms.Label
        Me.txt_booktitle = New System.Windows.Forms.TextBox
        Me.lbl_bookid = New System.Windows.Forms.Label
        Me.txt_bookid = New System.Windows.Forms.TextBox
        Me.lbl_studid = New System.Windows.Forms.Label
        Me.txt_sid = New System.Windows.Forms.TextBox
        Me.rd_return = New System.Windows.Forms.RadioButton
        Me.rd_issue = New System.Windows.Forms.RadioButton
        Me.btn_close = New System.Windows.Forms.Button
        Me.dg_books = New System.Windows.Forms.DataGrid
        Me.grb_fine = New System.Windows.Forms.GroupBox
        Me.Cmb_desc = New System.Windows.Forms.ComboBox
        Me.Lbl_disc = New System.Windows.Forms.Label
        Me.lbl_fine_disp = New System.Windows.Forms.Label
        Me.lbl_fine = New System.Windows.Forms.Label
        Me.btn_issue = New System.Windows.Forms.Button
        Me.btn_return = New System.Windows.Forms.Button
        Me.txt_search = New System.Windows.Forms.TextBox
        Me.btn_search = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.gb_rtn.SuspendLayout()
        CType(Me.dg_books, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grb_fine.SuspendLayout()
        Me.SuspendLayout()
        '
        'gb_rtn
        '
        Me.gb_rtn.Controls.Add(Me.txt_issue)
        Me.gb_rtn.Controls.Add(Me.lbl_branch)
        Me.gb_rtn.Controls.Add(Me.txt_branch)
        Me.gb_rtn.Controls.Add(Me.lbl_studnm)
        Me.gb_rtn.Controls.Add(Me.txt_sname)
        Me.gb_rtn.Controls.Add(Me.lbl_retdate)
        Me.gb_rtn.Controls.Add(Me.txt_ret)
        Me.gb_rtn.Controls.Add(Me.lbl_issuedate)
        Me.gb_rtn.Controls.Add(Me.lbl_booktitle)
        Me.gb_rtn.Controls.Add(Me.txt_booktitle)
        Me.gb_rtn.Controls.Add(Me.lbl_bookid)
        Me.gb_rtn.Controls.Add(Me.txt_bookid)
        Me.gb_rtn.Controls.Add(Me.lbl_studid)
        Me.gb_rtn.Controls.Add(Me.txt_sid)
        Me.gb_rtn.Controls.Add(Me.rd_return)
        Me.gb_rtn.Controls.Add(Me.rd_issue)
        Me.gb_rtn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gb_rtn.ForeColor = System.Drawing.Color.Navy
        Me.gb_rtn.Location = New System.Drawing.Point(24, 16)
        Me.gb_rtn.Name = "gb_rtn"
        Me.gb_rtn.Size = New System.Drawing.Size(288, 288)
        Me.gb_rtn.TabIndex = 0
        Me.gb_rtn.TabStop = False
        Me.gb_rtn.Text = "Issue && Return"
        '
        'txt_issue
        '
        Me.txt_issue.BackColor = System.Drawing.Color.White
        Me.txt_issue.Enabled = False
        Me.txt_issue.Location = New System.Drawing.Point(112, 216)
        Me.txt_issue.Name = "txt_issue"
        Me.txt_issue.Size = New System.Drawing.Size(160, 21)
        Me.txt_issue.TabIndex = 7
        Me.txt_issue.Text = ""
        '
        'lbl_branch
        '
        Me.lbl_branch.AutoSize = True
        Me.lbl_branch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_branch.Location = New System.Drawing.Point(16, 120)
        Me.lbl_branch.Name = "lbl_branch"
        Me.lbl_branch.Size = New System.Drawing.Size(58, 17)
        Me.lbl_branch.TabIndex = 9
        Me.lbl_branch.Text = "Class ID :"
        '
        'txt_branch
        '
        Me.txt_branch.BackColor = System.Drawing.Color.White
        Me.txt_branch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_branch.Location = New System.Drawing.Point(112, 120)
        Me.txt_branch.MaxLength = 20
        Me.txt_branch.Name = "txt_branch"
        Me.txt_branch.ReadOnly = True
        Me.txt_branch.Size = New System.Drawing.Size(160, 21)
        Me.txt_branch.TabIndex = 4
        Me.txt_branch.Text = ""
        '
        'lbl_studnm
        '
        Me.lbl_studnm.AutoSize = True
        Me.lbl_studnm.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_studnm.Location = New System.Drawing.Point(16, 88)
        Me.lbl_studnm.Name = "lbl_studnm"
        Me.lbl_studnm.Size = New System.Drawing.Size(96, 17)
        Me.lbl_studnm.TabIndex = 7
        Me.lbl_studnm.Text = "Student Name : "
        '
        'txt_sname
        '
        Me.txt_sname.BackColor = System.Drawing.Color.White
        Me.txt_sname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_sname.Location = New System.Drawing.Point(112, 88)
        Me.txt_sname.MaxLength = 50
        Me.txt_sname.Name = "txt_sname"
        Me.txt_sname.ReadOnly = True
        Me.txt_sname.Size = New System.Drawing.Size(160, 21)
        Me.txt_sname.TabIndex = 3
        Me.txt_sname.Text = ""
        '
        'lbl_retdate
        '
        Me.lbl_retdate.AutoSize = True
        Me.lbl_retdate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_retdate.Location = New System.Drawing.Point(16, 248)
        Me.lbl_retdate.Name = "lbl_retdate"
        Me.lbl_retdate.Size = New System.Drawing.Size(81, 17)
        Me.lbl_retdate.TabIndex = 4
        Me.lbl_retdate.Text = "Return Date :"
        '
        'txt_ret
        '
        Me.txt_ret.BackColor = System.Drawing.Color.White
        Me.txt_ret.Enabled = False
        Me.txt_ret.Location = New System.Drawing.Point(112, 248)
        Me.txt_ret.Name = "txt_ret"
        Me.txt_ret.Size = New System.Drawing.Size(160, 21)
        Me.txt_ret.TabIndex = 8
        Me.txt_ret.Text = ""
        '
        'lbl_issuedate
        '
        Me.lbl_issuedate.AutoSize = True
        Me.lbl_issuedate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_issuedate.Location = New System.Drawing.Point(16, 216)
        Me.lbl_issuedate.Name = "lbl_issuedate"
        Me.lbl_issuedate.Size = New System.Drawing.Size(76, 17)
        Me.lbl_issuedate.TabIndex = 3
        Me.lbl_issuedate.Text = "Issue Date : "
        '
        'lbl_booktitle
        '
        Me.lbl_booktitle.AutoSize = True
        Me.lbl_booktitle.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_booktitle.Location = New System.Drawing.Point(16, 184)
        Me.lbl_booktitle.Name = "lbl_booktitle"
        Me.lbl_booktitle.Size = New System.Drawing.Size(72, 17)
        Me.lbl_booktitle.TabIndex = 2
        Me.lbl_booktitle.Text = "Book Title : "
        '
        'txt_booktitle
        '
        Me.txt_booktitle.BackColor = System.Drawing.Color.White
        Me.txt_booktitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_booktitle.Location = New System.Drawing.Point(112, 184)
        Me.txt_booktitle.MaxLength = 50
        Me.txt_booktitle.Name = "txt_booktitle"
        Me.txt_booktitle.ReadOnly = True
        Me.txt_booktitle.Size = New System.Drawing.Size(160, 21)
        Me.txt_booktitle.TabIndex = 6
        Me.txt_booktitle.Text = ""
        '
        'lbl_bookid
        '
        Me.lbl_bookid.AutoSize = True
        Me.lbl_bookid.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_bookid.Location = New System.Drawing.Point(16, 152)
        Me.lbl_bookid.Name = "lbl_bookid"
        Me.lbl_bookid.Size = New System.Drawing.Size(56, 17)
        Me.lbl_bookid.TabIndex = 1
        Me.lbl_bookid.Text = "Book Id :"
        '
        'txt_bookid
        '
        Me.txt_bookid.BackColor = System.Drawing.Color.White
        Me.txt_bookid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txt_bookid.Location = New System.Drawing.Point(112, 152)
        Me.txt_bookid.MaxLength = 6
        Me.txt_bookid.Name = "txt_bookid"
        Me.txt_bookid.ReadOnly = True
        Me.txt_bookid.Size = New System.Drawing.Size(160, 21)
        Me.txt_bookid.TabIndex = 5
        Me.txt_bookid.Text = ""
        '
        'lbl_studid
        '
        Me.lbl_studid.AutoSize = True
        Me.lbl_studid.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_studid.Location = New System.Drawing.Point(16, 58)
        Me.lbl_studid.Name = "lbl_studid"
        Me.lbl_studid.Size = New System.Drawing.Size(79, 17)
        Me.lbl_studid.TabIndex = 0
        Me.lbl_studid.Text = "Student Id :  "
        '
        'txt_sid
        '
        Me.txt_sid.Location = New System.Drawing.Point(112, 56)
        Me.txt_sid.MaxLength = 6
        Me.txt_sid.Name = "txt_sid"
        Me.txt_sid.Size = New System.Drawing.Size(160, 21)
        Me.txt_sid.TabIndex = 2
        Me.txt_sid.Text = ""
        '
        'rd_return
        '
        Me.rd_return.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd_return.ForeColor = System.Drawing.Color.Blue
        Me.rd_return.Location = New System.Drawing.Point(160, 19)
        Me.rd_return.Name = "rd_return"
        Me.rd_return.Size = New System.Drawing.Size(72, 24)
        Me.rd_return.TabIndex = 1
        Me.rd_return.Text = "Return"
        '
        'rd_issue
        '
        Me.rd_issue.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd_issue.ForeColor = System.Drawing.Color.Blue
        Me.rd_issue.Location = New System.Drawing.Point(48, 20)
        Me.rd_issue.Name = "rd_issue"
        Me.rd_issue.Size = New System.Drawing.Size(72, 21)
        Me.rd_issue.TabIndex = 0
        Me.rd_issue.Text = "Issue"
        '
        'btn_close
        '
        Me.btn_close.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.ForeColor = System.Drawing.Color.Brown
        Me.btn_close.Location = New System.Drawing.Point(624, 416)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(72, 24)
        Me.btn_close.TabIndex = 11
        Me.btn_close.Text = "Close"
        '
        'dg_books
        '
        Me.dg_books.AlternatingBackColor = System.Drawing.Color.LightGray
        Me.dg_books.BackColor = System.Drawing.Color.Gainsboro
        Me.dg_books.BackgroundColor = System.Drawing.Color.Silver
        Me.dg_books.CaptionBackColor = System.Drawing.Color.LightSteelBlue
        Me.dg_books.CaptionForeColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.DataMember = ""
        Me.dg_books.FlatMode = True
        Me.dg_books.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dg_books.ForeColor = System.Drawing.Color.Black
        Me.dg_books.GridLineColor = System.Drawing.Color.White
        Me.dg_books.HeaderBackColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dg_books.HeaderForeColor = System.Drawing.Color.White
        Me.dg_books.LinkColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.Location = New System.Drawing.Point(328, 32)
        Me.dg_books.Name = "dg_books"
        Me.dg_books.ParentRowsBackColor = System.Drawing.Color.DarkGray
        Me.dg_books.ParentRowsForeColor = System.Drawing.Color.Black
        Me.dg_books.ReadOnly = True
        Me.dg_books.SelectionBackColor = System.Drawing.Color.CadetBlue
        Me.dg_books.SelectionForeColor = System.Drawing.Color.White
        Me.dg_books.Size = New System.Drawing.Size(416, 368)
        Me.dg_books.TabIndex = 12
        '
        'grb_fine
        '
        Me.grb_fine.Controls.Add(Me.Cmb_desc)
        Me.grb_fine.Controls.Add(Me.Lbl_disc)
        Me.grb_fine.Controls.Add(Me.lbl_fine_disp)
        Me.grb_fine.Controls.Add(Me.lbl_fine)
        Me.grb_fine.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb_fine.ForeColor = System.Drawing.Color.Navy
        Me.grb_fine.Location = New System.Drawing.Point(24, 312)
        Me.grb_fine.Name = "grb_fine"
        Me.grb_fine.Size = New System.Drawing.Size(288, 88)
        Me.grb_fine.TabIndex = 18
        Me.grb_fine.TabStop = False
        Me.grb_fine.Text = "Fine Details"
        '
        'Cmb_desc
        '
        Me.Cmb_desc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_desc.Items.AddRange(New Object() {"Late fine", "Book Damaged / Lost"})
        Me.Cmb_desc.Location = New System.Drawing.Point(112, 56)
        Me.Cmb_desc.Name = "Cmb_desc"
        Me.Cmb_desc.Size = New System.Drawing.Size(160, 21)
        Me.Cmb_desc.TabIndex = 7
        '
        'Lbl_disc
        '
        Me.Lbl_disc.AutoSize = True
        Me.Lbl_disc.Location = New System.Drawing.Point(16, 59)
        Me.Lbl_disc.Name = "Lbl_disc"
        Me.Lbl_disc.Size = New System.Drawing.Size(80, 17)
        Me.Lbl_disc.TabIndex = 2
        Me.Lbl_disc.Text = "Description  :"
        '
        'lbl_fine_disp
        '
        Me.lbl_fine_disp.BackColor = System.Drawing.Color.White
        Me.lbl_fine_disp.ForeColor = System.Drawing.Color.Red
        Me.lbl_fine_disp.Location = New System.Drawing.Point(112, 30)
        Me.lbl_fine_disp.Name = "lbl_fine_disp"
        Me.lbl_fine_disp.Size = New System.Drawing.Size(160, 16)
        Me.lbl_fine_disp.TabIndex = 1
        '
        'lbl_fine
        '
        Me.lbl_fine.AutoSize = True
        Me.lbl_fine.Location = New System.Drawing.Point(16, 32)
        Me.lbl_fine.Name = "lbl_fine"
        Me.lbl_fine.Size = New System.Drawing.Size(39, 17)
        Me.lbl_fine.TabIndex = 0
        Me.lbl_fine.Text = "Fine : "
        '
        'btn_issue
        '
        Me.btn_issue.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_issue.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_issue.ForeColor = System.Drawing.Color.Brown
        Me.btn_issue.Location = New System.Drawing.Point(88, 416)
        Me.btn_issue.Name = "btn_issue"
        Me.btn_issue.Size = New System.Drawing.Size(75, 32)
        Me.btn_issue.TabIndex = 9
        Me.btn_issue.Text = "&Issue"
        '
        'btn_return
        '
        Me.btn_return.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_return.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_return.ForeColor = System.Drawing.Color.Brown
        Me.btn_return.Location = New System.Drawing.Point(176, 416)
        Me.btn_return.Name = "btn_return"
        Me.btn_return.Size = New System.Drawing.Size(75, 32)
        Me.btn_return.TabIndex = 10
        Me.btn_return.Text = "&Return"
        '
        'txt_search
        '
        Me.txt_search.Location = New System.Drawing.Point(328, 416)
        Me.txt_search.Name = "txt_search"
        Me.txt_search.Size = New System.Drawing.Size(120, 22)
        Me.txt_search.TabIndex = 13
        Me.txt_search.Text = ""
        '
        'btn_search
        '
        Me.btn_search.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_search.ForeColor = System.Drawing.Color.Brown
        Me.btn_search.Location = New System.Drawing.Point(456, 416)
        Me.btn_search.Name = "btn_search"
        Me.btn_search.Size = New System.Drawing.Size(56, 24)
        Me.btn_search.TabIndex = 14
        Me.btn_search.Text = "search"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(328, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 17)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Select the book to be issued or returned :"
        '
        'transaction
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.ClientSize = New System.Drawing.Size(744, 470)
        Me.Controls.Add(Me.btn_search)
        Me.Controls.Add(Me.txt_search)
        Me.Controls.Add(Me.btn_return)
        Me.Controls.Add(Me.btn_issue)
        Me.Controls.Add(Me.grb_fine)
        Me.Controls.Add(Me.gb_rtn)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.dg_books)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "transaction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Transaction"
        Me.gb_rtn.ResumeLayout(False)
        CType(Me.dg_books, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grb_fine.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim dv As DataView
    Dim i, f_charge As Integer
    Dim d As Date
    Dim f As Integer

    Private Sub transaction_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        conn.Close()
        Try

            conn.Open() 'opening connection
            rd_issue.Select()

            cmd = New OleDbCommand("select F_Charge from tbloptions", conn)


            '        '    ' storing fine charge in a variable
            f_charge = CType(cmd.ExecuteScalar, Integer)

        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
        Finally
            txt_sid.Select()
            cmd = Nothing
            conn.Close()
        End Try
    End Sub



    'method to fetch books info. and display it in the grid
    Sub issue_fillgrid()
        Try
            da = New OleDbDataAdapter("select * from tblbookinfo where bookid not in (select bookid from tbltransaction)", conn)
            ds = New DataSet
            da.Fill(ds, "tblbookinfo")
            dv = New DataView(ds.Tables(0))
            dv.Sort = "bookid"
            dg_books.DataSource = dv
        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)

        Finally

            '    'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing

        End Try

    End Sub

    Sub return_fillgrid()

        Try

            da = New OleDbDataAdapter("select s1.Enrollno,s1.Name,s1.Classid,b1.bookid,b1.booktitle,t1.issuedate,t1.returndate from tblStudentsRecords s1,tblbookinfo b1,tbltransaction t1 where s1.Enrollno=t1.studenrollno and t1.bookid=b1.bookid", conn)
            ds = New DataSet
            da.Fill(ds, "tblStudentsRecords")

            dv = New DataView(ds.Tables(0))
            dv.Sort = "Enrollno"

            dg_books.DataSource = dv


        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)

            'Catch err As System.Exception
            '    MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally

            'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing

        End Try

    End Sub



    Private Sub rd_issue_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rd_issue.CheckedChanged

        issue_fillgrid() 'filling book info in the grid
        grb_fine.Enabled = False
        Cmb_desc.SelectedIndex = -1
        btn_return.Enabled = False
        btn_issue.Enabled = True
        txt_issue.Text = Format(Date.Today, "dd-MM-yyyy")
        txt_ret.Text = Format(Date.Today.AddDays(7), "dd-MM-yyyy")
        dg_books.CaptionText = "Availbale Books"
    End Sub

    Private Sub btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub rd_return_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rd_return.CheckedChanged

        ''enabling controls
        return_fillgrid() 'filling student data info in the grid
        grb_fine.Enabled = True
        btn_return.Enabled = True
        btn_issue.Enabled = False
        dg_books.CaptionText = "Issued Books Information."
        txt_ret.Text = Format(Date.Today, "dd-MM-yyyy")
        txt_issue.Clear()
        Cmb_desc.SelectedIndex = 0
        lbl_fine_disp.Text = ""
        clearfields()
    End Sub

    Private Sub btn_issue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_issue.Click

        Dim j As Short = 0

        Try

            j = check_if_issued()

            If j = 1 Then
                MsgBox("Can not issue,A book is already been issued to this student.", MessageBoxIcon.Stop)
            Else

                If txt_sid.Text <> "" AndAlso txt_sname.Text <> "" AndAlso txt_branch.Text <> "" AndAlso txt_bookid.Text <> "" AndAlso txt_booktitle.Text <> "" Then
                    'inserting record
                    cmd = New OleDbCommand
                    cmd.Connection = conn
                    conn.Close()
                    conn.Open()
                    cmd.CommandText = "insert into tbltransaction values('" & txt_sid.Text & "','" & txt_bookid.Text & "','" & Date.Today.ToShortDateString & "','" & Date.Today.AddDays(7) & "')"
                    cmd.ExecuteNonQuery()
                    MsgBox("Book issued successfully!!", MessageBoxIcon.Information)
                    issue_fillgrid()
                    clearfields()

                Else 'one or more fields are blank

                    MsgBox("All fields are mandatory to fill." & vbNewLine & "Enter the student ID and select the book from the list of available books.", MessageBoxIcon.Warning)
                    txt_sid.Focus()

                End If

            End If


        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
            txt_bookid.Focus()

        Finally
            cmd = Nothing
            conn.Close()
        End Try




    End Sub

    Sub get_from_grid()

        Try

            i = dg_books.CurrentRowIndex
            If rd_issue.Checked = True Then
                txt_bookid.Text = dg_books.Item(i, 0)
                txt_booktitle.Text = dg_books.Item(i, 1)
            Else
                txt_sid.Text = dg_books.Item(i, 0)
                txt_sname.Text = dg_books.Item(i, 1)
                txt_branch.Text = dg_books.Item(i, 2)
                txt_bookid.Text = dg_books.Item(i, 3)
                txt_booktitle.Text = dg_books.Item(i, 4)
                txt_issue.Text = Format(dg_books.Item(i, 5), "dd-MM-yyyy")

            End If

            Cmb_desc.SelectedIndex = 0

        Catch err As Exception
            MsgBox(err.Message)
        End Try
    End Sub


    Private Sub txt_sid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_sid.KeyPress
        If Asc(e.KeyChar) = Keys.Enter Then
            fill_data()

        End If

    End Sub

    Sub cleardatabind()
        txt_sid.DataBindings.Clear()
        txt_sname.DataBindings.Clear()
        txt_branch.DataBindings.Clear()
        txt_bookid.DataBindings.Clear()
        txt_booktitle.DataBindings.Clear()
        txt_issue.DataBindings.Clear()
    End Sub


    Sub clearfields()
        txt_sid.Clear()
        txt_sname.Clear()
        txt_branch.Clear()
        txt_bookid.Clear()
        txt_booktitle.Clear()
        txt_sid.Focus()
    End Sub

    Private Sub dg_books_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_books.Click

        get_from_grid()

        If rd_return.Checked = True Then
            cal_fine()
        End If

    End Sub

    Private Sub dg_books_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_books.CurrentCellChanged
        get_from_grid()
        If rd_return.Checked = True Then
            cal_fine()
        End If
    End Sub

    Private Function check_if_issued() As Short
        Dim bid As String
        Try
            cmd = New OleDbCommand("select bookid from tbltransaction where studenrollno= " & Integer.Parse(txt_sid.Text), conn)
            conn.Close()
            conn.Open()

            ''    ' storing fine charge in a variable
            bid = CType(cmd.ExecuteScalar, String)

            If bid <> "" Then
                Return 1
            Else
                Return 0
            End If


        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
            ''    Me.Close()

        Finally

            cmd = Nothing
            conn.Close()
        End Try
    End Function

    Private Sub btn_new_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        clearfields()
    End Sub

    Private Sub btn_return_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_return.Click

        Try

            If txt_sid.Text <> "" AndAlso txt_sname.Text <> "" AndAlso txt_branch.Text <> "" _
                 AndAlso txt_bookid.Text <> "" AndAlso txt_booktitle.Text <> "" Then

                '        'deleting the record
                cmd = New OleDbCommand
                cmd.Connection = conn
                conn.Open()
                cmd.CommandText = "delete from tbltransaction where studenrollno= " & Integer.Parse(txt_sid.Text)
                i = cmd.ExecuteNonQuery()
                '     conn.Close()
                If i > 0 Then

                    If lbl_fine_disp.Text <> "0" Then

                        cmd = New OleDbCommand
                        cmd.Connection = conn
                        conn.Close()
                        conn.Open()
                        cmd.CommandText = "insert into tblfine values('" & txt_sid.Text & "'," & Val(lbl_fine_disp.Text) & ",'" & Cmb_desc.Text & "','" & Date.Today.ToShortDateString & "') "
                        cmd.ExecuteNonQuery()

                    End If
                    MsgBox("Book successfully returned..Entry Deleted!!!", MessageBoxIcon.Information)
                    return_fillgrid()
                    clearfields()
                    lbl_fine_disp.Text = ""
                    Cmb_desc.SelectedIndex = 0
                    txt_issue.Clear()

                Else
                    MsgBox("Book is not present.", MessageBoxIcon.Stop)
                    txt_bookid.Focus()
                End If

            Else

                MsgBox("All fields are mandatory to fill." & vbNewLine & "Enter the student ID or select from the list shown by clicking on it.", MessageBoxIcon.Warning)
                clearfields()
                txt_sid.Focus()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
        Finally
            cmd = Nothing
            conn.Close()
        End Try
    End Sub


    Sub cal_fine()

        Try
            If txt_sid.Text <> "" AndAlso txt_sname.Text <> "" AndAlso txt_branch.Text <> "" AndAlso txt_bookid.Text <> "" AndAlso txt_booktitle.Text <> "" Then

                If Cmb_desc.SelectedItem = "Late fine" Then
                    'calculating fine

                    cmd = New OleDbCommand("select issuedate from tbltransaction where studenrollno= " & Integer.Parse(txt_sid.Text), conn)
                    ' storing fine charge in a variable
                    conn.Close()
                    conn.Open()
                    d = CType(cmd.ExecuteScalar, Date)
                    If (DateDiff(DateInterval.Day, d, Date.Today) - 7) > 0 Then
                        lbl_fine_disp.Text = f_charge * (DateDiff(DateInterval.Day, d, Date.Today) - 7)
                    Else
                        lbl_fine_disp.Text = "0"
                    End If
                    conn.Close()
                Else 'book lost

                    cmd = New OleDbCommand("select bookprice from tblbookinfo where bookid='" & txt_bookid.Text & "'", conn)
                    conn.Close()
                    conn.Open()
                    ' storing fine charge in a variable
                    f = CType(cmd.ExecuteScalar, Integer)

                    lbl_fine_disp.Text = f


                End If

            End If



        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)



        Finally

            'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing
            conn.Close()
        End Try
    End Sub

    Private Sub Cmb_desc_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_desc.SelectedIndexChanged
        cal_fine()
    End Sub

    Private Sub transaction_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        conn.Close()
    End Sub

    Private Sub txt_sid_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_sid.LostFocus

        If txt_sid.Text <> "" Then
            fill_data()
        End If

    End Sub


    Sub fill_data()

        Try

            cleardatabind()
            da = New OleDbDataAdapter("select Name,Classid from tblStudentsRecords where Enrollno= " & txt_sid.Text, conn)
            ds = New DataSet
            da.Fill(ds, "tblStudentsRecords")
            If ds.Tables(0).Rows.Count > 0 Then
                dv = New DataView(ds.Tables(0))
                txt_sname.DataBindings.Add("Text", dv, "Name")
                txt_branch.DataBindings.Add("Text", dv, "Classid")
                If rd_issue.Checked = False Then
                    da = New OleDbDataAdapter("select b1.bookid,b1.booktitle,t1.issuedate from tblbookinfo b1,tbltransaction t1 where b1.bookid=(select t2.bookid from tbltransaction t2 where t2.studenrollno= " & txt_sid.Text & ") and t1.bookid=b1.bookid", conn)
                    ds = New DataSet
                    da.Fill(ds, "tblStudentsRecords")
                    dv = New DataView(ds.Tables(0))

                    If ds.Tables(0).Rows.Count > 0 Then
                        txt_bookid.DataBindings.Add("Text", dv, "bookid")
                        txt_booktitle.DataBindings.Add("Text", dv, "booktitle")
                        txt_issue.DataBindings.Add("Text", dv, "issuedate")

                        'displaying fine
                        cal_fine()
                    Else
                        txt_sname.Clear()
                        txt_branch.Clear()
                        txt_bookid.Clear()
                        txt_booktitle.Clear()
                    End If


                End If

            Else

                txt_sname.Clear()
                txt_branch.Clear()
                txt_bookid.Clear()
                txt_booktitle.Clear()

            End If


        Catch ex As Exception
            MsgBox(ex.Message, , MessageBoxIcon.Error)


        Finally

            '    'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing
            Cmb_desc.SelectedIndex = 0

        End Try
    End Sub
End Class

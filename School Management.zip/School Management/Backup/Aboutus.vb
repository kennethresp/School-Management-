Public Class Aboutus
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtInformation As System.Windows.Forms.TextBox
    Friend WithEvents picHeader As System.Windows.Forms.PictureBox
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents bttnInfo As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtInformation = New System.Windows.Forms.TextBox
        Me.picHeader = New System.Windows.Forms.PictureBox
        Me.bttnCancel = New System.Windows.Forms.Button
        Me.bttnInfo = New System.Windows.Forms.Button
        Me.label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'txtInformation
        '
        Me.txtInformation.BackColor = System.Drawing.SystemColors.HighlightText
        Me.txtInformation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtInformation.ForeColor = System.Drawing.SystemColors.Highlight
        Me.txtInformation.Location = New System.Drawing.Point(24, 88)
        Me.txtInformation.Multiline = True
        Me.txtInformation.Name = "txtInformation"
        Me.txtInformation.ReadOnly = True
        Me.txtInformation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtInformation.Size = New System.Drawing.Size(500, 176)
        Me.txtInformation.TabIndex = 16
        Me.txtInformation.Text = "If you want more software like the ff:" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     1.) Inventory System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     2.) Billi" & _
        "ng System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     3.) Accounting System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     4.) Payroll System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     5.) Account" & _
        "s Receivable System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     6.) Accounts Payable System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     7.) Information Syst" & _
        "em" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     8.) School Management System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "     9.) Online Reservation System" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "   10" & _
        ".) and etc." & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "NOTE: If you want also to buy XP Professional Icons in affordable" & _
        " price" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "[16x16, 24x24, 32x32 and 48x48 Format] - just give me a call" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "just c" & _
        "ontact me at my cellular number: +639287899820" & Microsoft.VisualBasic.ChrW(13) & Microsoft.VisualBasic.ChrW(10) & "for more details just visit my w" & _
        "ebsite at www.junaldlagod.cjb.net"
        '
        'picHeader
        '
        Me.picHeader.BackColor = System.Drawing.SystemColors.Highlight
        Me.picHeader.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picHeader.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picHeader.Location = New System.Drawing.Point(24, 8)
        Me.picHeader.Name = "picHeader"
        Me.picHeader.Size = New System.Drawing.Size(504, 80)
        Me.picHeader.TabIndex = 15
        Me.picHeader.TabStop = False
        '
        'bttnCancel
        '
        Me.bttnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnCancel.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.bttnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnCancel.Location = New System.Drawing.Point(424, 312)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(104, 25)
        Me.bttnCancel.TabIndex = 14
        Me.bttnCancel.Text = "&Cancel"
        '
        'bttnInfo
        '
        Me.bttnInfo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnInfo.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.bttnInfo.ForeColor = System.Drawing.Color.Brown
        Me.bttnInfo.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnInfo.Location = New System.Drawing.Point(424, 288)
        Me.bttnInfo.Name = "bttnInfo"
        Me.bttnInfo.Size = New System.Drawing.Size(104, 25)
        Me.bttnInfo.TabIndex = 13
        Me.bttnInfo.Text = "&Short Info"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.label1.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.label1.Location = New System.Drawing.Point(40, 288)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(376, 48)
        Me.label1.TabIndex = 12
        Me.label1.Text = "Warning: This software was distributed for free by the author only. Any form of s" & _
        "elling or reproduction of this software without permission from the author is st" & _
        "rictly prohibited."
        Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Aboutus
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(544, 358)
        Me.Controls.Add(Me.txtInformation)
        Me.Controls.Add(Me.picHeader)
        Me.Controls.Add(Me.bttnCancel)
        Me.Controls.Add(Me.bttnInfo)
        Me.Controls.Add(Me.label1)
        Me.Name = "Aboutus"
        Me.Text = "Aboutus"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub bttnInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnInfo.Click
        MessageBox.Show("NOTE: This application was created by: ZenexInfo Technologies\Windowbaseapp. Programmer/Web Developer/Designer/Technician.\n\n\n", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Aboutus_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        babout = True
    End Sub

    Private Sub Aboutus_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        babout = False
    End Sub
End Class

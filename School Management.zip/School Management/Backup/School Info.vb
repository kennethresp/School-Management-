Public Class School_Info
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtschoolname As System.Windows.Forms.TextBox
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents txtschooladd As System.Windows.Forms.TextBox
    Friend WithEvents txtcontactno As System.Windows.Forms.TextBox
    Friend WithEvents btncancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtschoolname = New System.Windows.Forms.TextBox
        Me.btnupdate = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtschooladd = New System.Windows.Forms.TextBox
        Me.txtcontactno = New System.Windows.Forms.TextBox
        Me.btncancel = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(40, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "School Name :"
        '
        'txtschoolname
        '
        Me.txtschoolname.Location = New System.Drawing.Point(144, 16)
        Me.txtschoolname.Name = "txtschoolname"
        Me.txtschoolname.Size = New System.Drawing.Size(400, 20)
        Me.txtschoolname.TabIndex = 1
        Me.txtschoolname.Text = ""
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(208, 136)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 32)
        Me.btnupdate.TabIndex = 2
        Me.btnupdate.Text = "Update"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(40, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "School Address :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(40, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Contact Number :"
        '
        'txtschooladd
        '
        Me.txtschooladd.Location = New System.Drawing.Point(144, 56)
        Me.txtschooladd.Name = "txtschooladd"
        Me.txtschooladd.Size = New System.Drawing.Size(400, 20)
        Me.txtschooladd.TabIndex = 5
        Me.txtschooladd.Text = ""
        '
        'txtcontactno
        '
        Me.txtcontactno.Location = New System.Drawing.Point(144, 96)
        Me.txtcontactno.Name = "txtcontactno"
        Me.txtcontactno.Size = New System.Drawing.Size(400, 20)
        Me.txtcontactno.TabIndex = 6
        Me.txtcontactno.Text = ""
        '
        'btncancel
        '
        Me.btncancel.Location = New System.Drawing.Point(336, 136)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 32)
        Me.btncancel.TabIndex = 7
        Me.btncancel.Text = "Cancel"
        '
        'School_Info
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 182)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.txtcontactno)
        Me.Controls.Add(Me.txtschooladd)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.txtschoolname)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "School_Info"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "School_Info"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub School_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bschool = True
    End Sub

    Private Sub School_Info_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bschool = False
    End Sub
End Class

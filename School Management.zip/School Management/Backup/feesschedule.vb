Imports System.Data.OleDb
Public Class feesschedule
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtclassid As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtadminfees As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtlatefees As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtfpm As System.Windows.Forms.TextBox
    Friend WithEvents dgfee_s As System.Windows.Forms.DataGrid
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtclassid = New System.Windows.Forms.TextBox
        Me.txtfpm = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtadminfees = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtlatefees = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.dgfee_s = New System.Windows.Forms.DataGrid
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        CType(Me.dgfee_s, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Classid"
        '
        'txtclassid
        '
        Me.txtclassid.Location = New System.Drawing.Point(144, 32)
        Me.txtclassid.Name = "txtclassid"
        Me.txtclassid.Size = New System.Drawing.Size(144, 20)
        Me.txtclassid.TabIndex = 1
        Me.txtclassid.Text = ""
        '
        'txtfpm
        '
        Me.txtfpm.Location = New System.Drawing.Point(144, 64)
        Me.txtfpm.Name = "txtfpm"
        Me.txtfpm.Size = New System.Drawing.Size(144, 20)
        Me.txtfpm.TabIndex = 5
        Me.txtfpm.Text = ""
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(24, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Fees Per Month :"
        '
        'txtadminfees
        '
        Me.txtadminfees.Location = New System.Drawing.Point(144, 96)
        Me.txtadminfees.Name = "txtadminfees"
        Me.txtadminfees.Size = New System.Drawing.Size(144, 20)
        Me.txtadminfees.TabIndex = 7
        Me.txtadminfees.Text = ""
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(24, 96)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Admission Fees :"
        '
        'txtlatefees
        '
        Me.txtlatefees.Location = New System.Drawing.Point(144, 128)
        Me.txtlatefees.Name = "txtlatefees"
        Me.txtlatefees.Size = New System.Drawing.Size(144, 20)
        Me.txtlatefees.TabIndex = 9
        Me.txtlatefees.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(24, 128)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 16)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Late Fees :"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(112, 216)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Save"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(208, 216)
        Me.Button2.Name = "Button2"
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Cancel"
        '
        'dgfee_s
        '
        Me.dgfee_s.DataMember = ""
        Me.dgfee_s.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgfee_s.Location = New System.Drawing.Point(336, 40)
        Me.dgfee_s.Name = "dgfee_s"
        Me.dgfee_s.Size = New System.Drawing.Size(344, 176)
        Me.dgfee_s.TabIndex = 12
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(344, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(152, 16)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Class Wise Fees Detail"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtfpm)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtadminfees)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtlatefees)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtclassid)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(312, 176)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Fees Detail"
        '
        'feesschedule
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(688, 254)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.dgfee_s)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "feesschedule"
        Me.Text = "feesschedule"
        CType(Me.dgfee_s, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Sub fillgrid()
        Dim dv As DataView
        Try
            Dim objfillgrid As New clsschmngt("tblfeeschedule")
            dv = New DataView(objfillgrid.dt)
            dv.Sort = "classid"
            dgfee_s.DataSource = dv
        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
        Finally
            'dereferencing objects
            dv = Nothing
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtclassid.TextChanged

    End Sub

    Private Sub feesschedule_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call fillgrid()
    End Sub
    Dim ssql As String
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Try
            ssql = "Insert into tblfeeschedule (classid,feespermonth,adminfees,latefees)values ("
            ssql += txtclassid.Text + "," + txtfpm.Text + "," + txtadminfees.Text + "," + txtlatefees.Text + ")"
            'MsgBox(ssql)
            Dim objfee_s As New clsschmngt("tblfeeschedule", ssql)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Call fillgrid()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class

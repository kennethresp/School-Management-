Public Class Viewstudentoption
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents bttnPrint As System.Windows.Forms.Button
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radioButton3 As System.Windows.Forms.RadioButton
    Public WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Public WithEvents radioButton1 As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.bttnPrint = New System.Windows.Forms.Button
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.radioButton3 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'bttnPrint
        '
        Me.bttnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnPrint.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnPrint.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnPrint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnPrint.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnPrint.Location = New System.Drawing.Point(80, 168)
        Me.bttnPrint.Name = "bttnPrint"
        Me.bttnPrint.Size = New System.Drawing.Size(104, 25)
        Me.bttnPrint.TabIndex = 16
        Me.bttnPrint.Text = "&Print"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.radioButton3)
        Me.groupBox1.Controls.Add(Me.radioButton2)
        Me.groupBox1.Controls.Add(Me.radioButton1)
        Me.groupBox1.Location = New System.Drawing.Point(40, 32)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(184, 120)
        Me.groupBox1.TabIndex = 15
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Option"
        '
        'radioButton3
        '
        Me.radioButton3.Location = New System.Drawing.Point(8, 88)
        Me.radioButton3.Name = "radioButton3"
        Me.radioButton3.Size = New System.Drawing.Size(160, 24)
        Me.radioButton3.TabIndex = 2
        Me.radioButton3.Text = "View Records in Level"
        '
        'radioButton2
        '
        Me.radioButton2.Checked = True
        Me.radioButton2.Location = New System.Drawing.Point(8, 56)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(168, 24)
        Me.radioButton2.TabIndex = 1
        Me.radioButton2.TabStop = True
        Me.radioButton2.Text = "View Records per Section"
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(8, 24)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(152, 24)
        Me.radioButton1.TabIndex = 0
        Me.radioButton1.Text = "View Selected Record"
        '
        'Viewstudentoption
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(256, 208)
        Me.Controls.Add(Me.bttnPrint)
        Me.Controls.Add(Me.groupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Viewstudentoption"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Viewstudentoption"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Viewstudentoption_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bviewstud = True
    End Sub

    Private Sub Viewstudentoption_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bviewstud = False
    End Sub
End Class

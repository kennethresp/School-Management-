Public Class Search
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents bttnOK As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Search))
        Me.label1 = New System.Windows.Forms.Label
        Me.txtSearch = New System.Windows.Forms.TextBox
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.bttnCancel = New System.Windows.Forms.Button
        Me.bttnOK = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(24, 56)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(158, 16)
        Me.label1.TabIndex = 18
        Me.label1.Text = "Enter Student Name to Search"
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(24, 72)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(376, 22)
        Me.txtSearch.TabIndex = 14
        Me.txtSearch.Text = ""
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = CType(resources.GetObject("pictureBox1.Image"), System.Drawing.Image)
        Me.pictureBox1.Location = New System.Drawing.Point(24, 16)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(32, 32)
        Me.pictureBox1.TabIndex = 17
        Me.pictureBox1.TabStop = False
        '
        'bttnCancel
        '
        Me.bttnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnCancel.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.bttnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnCancel.Location = New System.Drawing.Point(312, 112)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(88, 25)
        Me.bttnCancel.TabIndex = 16
        Me.bttnCancel.Text = "&Cancel"
        '
        'bttnOK
        '
        Me.bttnOK.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnOK.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnOK.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.bttnOK.ForeColor = System.Drawing.Color.Brown
        Me.bttnOK.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnOK.Location = New System.Drawing.Point(216, 112)
        Me.bttnOK.Name = "bttnOK"
        Me.bttnOK.Size = New System.Drawing.Size(88, 25)
        Me.bttnOK.TabIndex = 15
        Me.bttnOK.Text = "&OK"
        '
        'Search
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(432, 158)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.bttnCancel)
        Me.Controls.Add(Me.bttnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Search"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Search"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Search_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bsearch = True
    End Sub

    Private Sub Search_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bsearch = False
    End Sub
End Class

Public Class View_year
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lvSchoolYear As System.Windows.Forms.ListView
    Friend WithEvents chSchoolYear As System.Windows.Forms.ColumnHeader
    Friend WithEvents chStatus As System.Windows.Forms.ColumnHeader
    Friend WithEvents bttnSelect As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lvSchoolYear = New System.Windows.Forms.ListView
        Me.chSchoolYear = New System.Windows.Forms.ColumnHeader
        Me.chStatus = New System.Windows.Forms.ColumnHeader
        Me.bttnSelect = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lvSchoolYear
        '
        Me.lvSchoolYear.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chSchoolYear, Me.chStatus})
        Me.lvSchoolYear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lvSchoolYear.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvSchoolYear.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.lvSchoolYear.FullRowSelect = True
        Me.lvSchoolYear.GridLines = True
        Me.lvSchoolYear.Location = New System.Drawing.Point(0, 0)
        Me.lvSchoolYear.Name = "lvSchoolYear"
        Me.lvSchoolYear.Size = New System.Drawing.Size(226, 232)
        Me.lvSchoolYear.TabIndex = 3
        Me.lvSchoolYear.View = System.Windows.Forms.View.Details
        '
        'chSchoolYear
        '
        Me.chSchoolYear.Text = "School Year"
        Me.chSchoolYear.Width = 136
        '
        'chStatus
        '
        Me.chStatus.Text = "Status"
        Me.chStatus.Width = 86
        '
        'bttnSelect
        '
        Me.bttnSelect.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnSelect.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnSelect.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnSelect.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.bttnSelect.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnSelect.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnSelect.Location = New System.Drawing.Point(112, 232)
        Me.bttnSelect.Name = "bttnSelect"
        Me.bttnSelect.Size = New System.Drawing.Size(104, 32)
        Me.bttnSelect.TabIndex = 72
        Me.bttnSelect.Text = "&Select"
        '
        'View_year
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(224, 270)
        Me.Controls.Add(Me.bttnSelect)
        Me.Controls.Add(Me.lvSchoolYear)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "View_year"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "View_year"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub View_year_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bviewy = True
        Dim filllist As New fillreader
        filllist.readrdr("tblschoolyear", conn, lvSchoolYear, "schoolyear")
    End Sub

  
    Private Sub View_year_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bviewy = False
    End Sub

    Private Sub bttnSelect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnSelect.Click
        If lvSchoolYear.SelectedItems.Count = Nothing Then
            MsgBox("Plz Select a Year for Student Records", MsgBoxStyle.Exclamation)
        Else
            If bstudrec = False Then
                Dim viewstudrec As New Students_Records
                viewstudrec.Show()
                schyear = lvSchoolYear.SelectedItems(0).Text
            End If
        End If
    End Sub
End Class

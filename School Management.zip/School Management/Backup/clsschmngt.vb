
Imports System.Data.OleDb
Public Class clsschmngt
    Public str As String = "Provider = Microsoft.jet.OLEDB.4.0;Data Source =D:\Vb.net2003 Projects\School Management\bin\raj.mdb"
    Public conn As New OleDbConnection(str)
    Public da As OleDbDataAdapter
    Public ds As DataSet
    Public dt As DataTable
    Public cb As New OleDbCommandBuilder(da)
    Public cmd As OleDbCommand
    Sub New(ByVal tblname As String)
        Try
            da = New OleDbDataAdapter("select * from " + tblname, conn)
            dt = New DataTable
            da.Fill(dt)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
    Sub New(ByVal tblname As String, ByVal ssql As String)
        Try
            conn.Close()
            conn.Open()
            cmd = New OleDbCommand(ssql, conn)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
    Public Function save(ByVal msg As String)
        '    Me.da.Update(dt)
        MsgBox(msg)
    End Function
    Dim rownew As DataRow
    Public Function addnew()
        rownew = dt.NewRow
        dt.Rows.Add(rownew)
    End Function
End Class

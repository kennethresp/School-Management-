Imports System.Data.SqlClient

Public Class students
    Inherits System.Windows.Forms.Form

    ' Dim cn As New SqlConnection("server=localhost;database=lms;uid=sa;password=;")
    'Dim da As SqlDataAdapter
    'Dim ds As DataSet
    'Dim cmd As SqlCommand
    'Dim dv As DataView
    'Dim ch As Char
    'Dim i As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_add As System.Windows.Forms.Button
    Friend WithEvents btn_remove As System.Windows.Forms.Button
    Friend WithEvents lbl_year As System.Windows.Forms.Label
    Friend WithEvents lbl_contact As System.Windows.Forms.Label
    Friend WithEvents lbl_address As System.Windows.Forms.Label
    Friend WithEvents lbl_name As System.Windows.Forms.Label
    Friend WithEvents lbl_studid As System.Windows.Forms.Label
    Friend WithEvents btn_close As System.Windows.Forms.Button
    Friend WithEvents lbl_branch As System.Windows.Forms.Label
    Friend WithEvents cmb_branch As System.Windows.Forms.ComboBox
    Friend WithEvents txt_contact As System.Windows.Forms.TextBox
    Friend WithEvents txt_add As System.Windows.Forms.TextBox
    Friend WithEvents txt_name As System.Windows.Forms.TextBox
    Friend WithEvents txt_sid As System.Windows.Forms.TextBox
    Friend WithEvents cmb_year As System.Windows.Forms.ComboBox
    Friend WithEvents dg_stud As System.Windows.Forms.DataGrid
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_help As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lbl_branch = New System.Windows.Forms.Label
        Me.cmb_branch = New System.Windows.Forms.ComboBox
        Me.cmb_year = New System.Windows.Forms.ComboBox
        Me.btn_add = New System.Windows.Forms.Button
        Me.btn_remove = New System.Windows.Forms.Button
        Me.lbl_year = New System.Windows.Forms.Label
        Me.txt_contact = New System.Windows.Forms.TextBox
        Me.lbl_address = New System.Windows.Forms.Label
        Me.txt_add = New System.Windows.Forms.TextBox
        Me.lbl_name = New System.Windows.Forms.Label
        Me.txt_name = New System.Windows.Forms.TextBox
        Me.txt_sid = New System.Windows.Forms.TextBox
        Me.lbl_studid = New System.Windows.Forms.Label
        Me.lbl_contact = New System.Windows.Forms.Label
        Me.btn_close = New System.Windows.Forms.Button
        Me.dg_stud = New System.Windows.Forms.DataGrid
        Me.Label1 = New System.Windows.Forms.Label
        Me.lbl_help = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.dg_stud, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lbl_help)
        Me.GroupBox1.Controls.Add(Me.lbl_branch)
        Me.GroupBox1.Controls.Add(Me.cmb_branch)
        Me.GroupBox1.Controls.Add(Me.cmb_year)
        Me.GroupBox1.Controls.Add(Me.btn_add)
        Me.GroupBox1.Controls.Add(Me.btn_remove)
        Me.GroupBox1.Controls.Add(Me.lbl_year)
        Me.GroupBox1.Controls.Add(Me.txt_contact)
        Me.GroupBox1.Controls.Add(Me.lbl_address)
        Me.GroupBox1.Controls.Add(Me.txt_add)
        Me.GroupBox1.Controls.Add(Me.lbl_name)
        Me.GroupBox1.Controls.Add(Me.txt_name)
        Me.GroupBox1.Controls.Add(Me.txt_sid)
        Me.GroupBox1.Controls.Add(Me.lbl_studid)
        Me.GroupBox1.Controls.Add(Me.lbl_contact)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox1.Location = New System.Drawing.Point(16, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 432)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Students Details"
        '
        'lbl_branch
        '
        Me.lbl_branch.AutoSize = True
        Me.lbl_branch.Location = New System.Drawing.Point(19, 304)
        Me.lbl_branch.Name = "lbl_branch"
        Me.lbl_branch.Size = New System.Drawing.Size(52, 17)
        Me.lbl_branch.TabIndex = 14
        Me.lbl_branch.Text = "Branch :"
        '
        'cmb_branch
        '
        Me.cmb_branch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_branch.Items.AddRange(New Object() {"Computer", "IT", "Entc", "Electronics", "Chemical", "Mechanical"})
        Me.cmb_branch.Location = New System.Drawing.Point(90, 304)
        Me.cmb_branch.MaxLength = 20
        Me.cmb_branch.Name = "cmb_branch"
        Me.cmb_branch.Size = New System.Drawing.Size(174, 21)
        Me.cmb_branch.TabIndex = 5
        '
        'cmb_year
        '
        Me.cmb_year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_year.Items.AddRange(New Object() {"F.E", "S.E", "T.E", "B.E"})
        Me.cmb_year.Location = New System.Drawing.Point(90, 264)
        Me.cmb_year.MaxLength = 4
        Me.cmb_year.Name = "cmb_year"
        Me.cmb_year.Size = New System.Drawing.Size(174, 21)
        Me.cmb_year.TabIndex = 4
        '
        'btn_add
        '
        Me.btn_add.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_add.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_add.Location = New System.Drawing.Point(56, 360)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.TabIndex = 6
        Me.btn_add.Text = "&Add"
        '
        'btn_remove
        '
        Me.btn_remove.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_remove.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_remove.Location = New System.Drawing.Point(144, 360)
        Me.btn_remove.Name = "btn_remove"
        Me.btn_remove.TabIndex = 7
        Me.btn_remove.Text = "&Remove"
        '
        'lbl_year
        '
        Me.lbl_year.AutoSize = True
        Me.lbl_year.Location = New System.Drawing.Point(17, 264)
        Me.lbl_year.Name = "lbl_year"
        Me.lbl_year.Size = New System.Drawing.Size(38, 17)
        Me.lbl_year.TabIndex = 4
        Me.lbl_year.Text = "Year :"
        '
        'txt_contact
        '
        Me.txt_contact.Location = New System.Drawing.Point(90, 224)
        Me.txt_contact.MaxLength = 15
        Me.txt_contact.Name = "txt_contact"
        Me.txt_contact.Size = New System.Drawing.Size(174, 21)
        Me.txt_contact.TabIndex = 3
        Me.txt_contact.Text = ""
        '
        'lbl_address
        '
        Me.lbl_address.AutoSize = True
        Me.lbl_address.Location = New System.Drawing.Point(16, 120)
        Me.lbl_address.Name = "lbl_address"
        Me.lbl_address.Size = New System.Drawing.Size(60, 17)
        Me.lbl_address.TabIndex = 2
        Me.lbl_address.Text = "Address : "
        '
        'txt_add
        '
        Me.txt_add.Location = New System.Drawing.Point(90, 120)
        Me.txt_add.MaxLength = 200
        Me.txt_add.Multiline = True
        Me.txt_add.Name = "txt_add"
        Me.txt_add.Size = New System.Drawing.Size(174, 84)
        Me.txt_add.TabIndex = 2
        Me.txt_add.Text = ""
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.Location = New System.Drawing.Point(16, 80)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(48, 17)
        Me.lbl_name.TabIndex = 1
        Me.lbl_name.Text = "Name : "
        '
        'txt_name
        '
        Me.txt_name.Location = New System.Drawing.Point(90, 80)
        Me.txt_name.MaxLength = 50
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(174, 21)
        Me.txt_name.TabIndex = 1
        Me.txt_name.Text = ""
        '
        'txt_sid
        '
        Me.txt_sid.Location = New System.Drawing.Point(90, 40)
        Me.txt_sid.MaxLength = 6
        Me.txt_sid.Name = "txt_sid"
        Me.txt_sid.Size = New System.Drawing.Size(88, 21)
        Me.txt_sid.TabIndex = 0
        Me.txt_sid.Text = ""
        '
        'lbl_studid
        '
        Me.lbl_studid.AutoSize = True
        Me.lbl_studid.Location = New System.Drawing.Point(16, 40)
        Me.lbl_studid.Name = "lbl_studid"
        Me.lbl_studid.Size = New System.Drawing.Size(76, 17)
        Me.lbl_studid.TabIndex = 0
        Me.lbl_studid.Text = "Student Id : "
        '
        'lbl_contact
        '
        Me.lbl_contact.AutoSize = True
        Me.lbl_contact.Location = New System.Drawing.Point(16, 226)
        Me.lbl_contact.Name = "lbl_contact"
        Me.lbl_contact.Size = New System.Drawing.Size(78, 17)
        Me.lbl_contact.TabIndex = 3
        Me.lbl_contact.Text = "Contact No : "
        '
        'btn_close
        '
        Me.btn_close.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.Location = New System.Drawing.Point(712, 480)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(72, 24)
        Me.btn_close.TabIndex = 8
        Me.btn_close.Text = "Close"
        '
        'dg_stud
        '
        Me.dg_stud.AlternatingBackColor = System.Drawing.Color.LightGray
        Me.dg_stud.BackColor = System.Drawing.Color.Gainsboro
        Me.dg_stud.BackgroundColor = System.Drawing.Color.Silver
        Me.dg_stud.CaptionBackColor = System.Drawing.Color.LightSteelBlue
        Me.dg_stud.CaptionForeColor = System.Drawing.Color.MidnightBlue
        Me.dg_stud.CaptionText = "Students Information"
        Me.dg_stud.DataMember = ""
        Me.dg_stud.FlatMode = True
        Me.dg_stud.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dg_stud.ForeColor = System.Drawing.Color.Black
        Me.dg_stud.GridLineColor = System.Drawing.Color.White
        Me.dg_stud.HeaderBackColor = System.Drawing.Color.MidnightBlue
        Me.dg_stud.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dg_stud.HeaderForeColor = System.Drawing.Color.White
        Me.dg_stud.LinkColor = System.Drawing.Color.White
        Me.dg_stud.Location = New System.Drawing.Point(312, 40)
        Me.dg_stud.Name = "dg_stud"
        Me.dg_stud.ParentRowsBackColor = System.Drawing.Color.DarkGray
        Me.dg_stud.ParentRowsForeColor = System.Drawing.Color.Black
        Me.dg_stud.ReadOnly = True
        Me.dg_stud.SelectionBackColor = System.Drawing.Color.CadetBlue
        Me.dg_stud.SelectionForeColor = System.Drawing.Color.White
        Me.dg_stud.Size = New System.Drawing.Size(472, 424)
        Me.dg_stud.TabIndex = 9
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(312, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Select the student record : "
        '
        'lbl_help
        '
        Me.lbl_help.AutoSize = True
        Me.lbl_help.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lbl_help.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_help.ForeColor = System.Drawing.Color.Blue
        Me.lbl_help.Location = New System.Drawing.Point(183, 408)
        Me.lbl_help.Name = "lbl_help"
        Me.lbl_help.Size = New System.Drawing.Size(91, 17)
        Me.lbl_help.TabIndex = 15
        Me.lbl_help.Text = "How to update?"
        '
        'students
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(804, 525)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.dg_stud)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "students"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Students Information"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dg_stud, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region



    'Private Sub students_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    '    'Try

    '    '    cn.Open() 'opening connection
    '    '    fillgrid() 'filling student data in the grid


    '    'Catch ex As SqlException
    '    '    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '    Me.Close()

    '    'Finally
    '    '    GroupBox1.Focus()
    '    '    txt_sid.Focus()

    '    'End Try
    'End Sub

    ''method to fetch student info and display it in the grid
    'Sub fillgrid()

    '    'Try

    '    '    da = New SqlDataAdapter("select * from stud_info")
    '    '    ds = New DataSet
    '    '    da.Fill(ds, "stud_info")
    '    '    dv = New DataView(ds.Tables(0))
    '    '    dv.Sort = "S_id"

    '    '    dg_stud.DataSource = dv


    '    'Catch ex As SqlException
    '    '    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Catch err As System.Exception
    '    '    MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Finally

    '    '    'dereferencing objects
    '    '    da = Nothing
    '    '    ds = Nothing
    '    '    dv = Nothing

    '    'End Try

    'End Sub

    'Private Sub btn_add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_add.Click

    '    '    Try

    '    '        If txt_sid.Text <> "" AndAlso txt_name.Text <> "" _
    '    'AndAlso txt_add.Text <> "" AndAlso txt_contact.Text <> "" _
    '    'AndAlso cmb_year.Text <> "" AndAlso cmb_branch.Text <> "" Then

    '    '            'inserting record
    '    '            cmd = New SqlCommand
    '    '            cmd.Connection = cn
    '    '            cmd.CommandText = "insert into stud_info values('" & txt_sid.Text & "','" & txt_name.Text & "','" & txt_add.Text & "','" & txt_contact.Text & "','" & cmb_year.Text & "','" & cmb_branch.Text & "')"
    '    '            cmd.ExecuteNonQuery()
    '    '            MessageBox.Show("Student record added successfully!!", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    '            fillgrid()
    '    '            clearfields()

    '    '        Else 'one or more fields are blank

    '    '            MessageBox.Show("All fields are mandatory to fill.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Warning)

    '    '        End If

    '    '    Catch ex As SqlException
    '    '        MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '        txt_sid.Focus()

    '    '    Catch err As System.Exception
    '    '        MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    '        txt_sid.Focus()

    '    '    Finally

    '    '        cmd = Nothing

    '    '    End Try

    'End Sub
    'Sub cleardatabind()
    '    'txt_sid.DataBindings.Clear()
    '    'txt_name.DataBindings.Clear()
    '    'txt_add.DataBindings.Clear()
    '    'txt_contact.DataBindings.Clear()
    '    'cmb_branch.DataBindings.Clear()
    '    'cmb_year.DataBindings.Clear()
    'End Sub
    'Sub clearfields()
    '    'txt_sid.Clear()
    '    'txt_name.Clear()
    '    'txt_add.Clear()
    '    'txt_contact.Clear()
    '    'cmb_branch.SelectedIndex = -1
    '    'cmb_year.SelectedIndex = -1
    '    'txt_sid.Focus()
    'End Sub


    'Private Sub txt_sid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_sid.KeyPress

    '    'ch = e.KeyChar

    '    'If ch.IsSymbol(ch) Or ch.IsPunctuation(ch) Then
    '    '    e.Handled = True
    '    '    MessageBox.Show("Symbols are not allowed.", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Stop)
    '    'End If

    '    'If Asc(e.KeyChar) = Keys.Enter Then

    '    '    fill_on_keypress()

    '    'End If

    'End Sub

    'Sub fill_on_keypress()

    '    'Try
    '    '    cleardatabind()
    '    '    da = New SqlDataAdapter("select * from stud_info where S_Id='" & txt_sid.Text & "'", cn)
    '    '    ds = New DataSet
    '    '    da.Fill(ds, "stud_info")
    '    '    dv = New DataView(ds.Tables(0))


    '    '    If ds.Tables("stud_info").Rows.Count <> 0 Then 'no rows selected

    '    '        dv = New DataView(ds.Tables(0))

    '    '        txt_name.DataBindings.Add("Text", dv, "Name")
    '    '        txt_add.DataBindings.Add("Text", dv, "Address")
    '    '        txt_contact.DataBindings.Add("Text", dv, "Contact")
    '    '        cmb_year.DataBindings.Add("Text", dv, "A_year")
    '    '        cmb_branch.DataBindings.Add("Text", dv, "Branch")


    '    '    Else

    '    '        txt_name.Clear()
    '    '        txt_add.Clear()
    '    '        txt_contact.Clear()
    '    '        cmb_year.SelectedIndex = -1
    '    '        cmb_branch.SelectedIndex = -1

    '    '    End If


    '    'Catch ex As SqlException
    '    '    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Catch err As System.Exception
    '    '    MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Finally

    '    '    'dereferencing objects
    '    '    da = Nothing
    '    '    ds = Nothing
    '    '    dv = Nothing

    '    'End Try

    'End Sub



    'Private Sub txt_name_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_name.KeyPress

    '    'ch = e.KeyChar

    '    'If Not (ch.IsLetter(ch) Or ch.IsWhiteSpace(ch) Or Asc(e.KeyChar) = Keys.Back) Then
    '    '    e.Handled = True
    '    'End If
    'End Sub



    'Private Sub btn_remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_remove.Click
    '    'Try

    '    '    If txt_sid.Text <> "" AndAlso txt_name.Text <> "" Then

    '    '        'deleting the record
    '    '        cmd = New SqlCommand
    '    '        cmd.Connection = cn
    '    '        cmd.CommandText = "delete from stud_info where S_id='" & txt_sid.Text & "' and S_id not in (select S_Id from trans)"
    '    '        i = cmd.ExecuteNonQuery()

    '    '        If i > 0 Then
    '    '            MessageBox.Show("Student record deleted successfully.", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    '            fillgrid()
    '    '            clearfields()
    '    '        Else
    '    '            MessageBox.Show("Can not delete because Book(s) is issued to this student.", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '    '            txt_sid.Focus()
    '    '        End If

    '    '    Else

    '    '        txt_sid.Focus()

    '    '    End If


    '    'Catch ex As SqlException
    '    '    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Catch err As System.Exception
    '    '    MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    'Finally

    '    '    cmd = Nothing


    '    'End Try



    'End Sub

    'Sub get_from_grid()
    '    'Try
    '    '    i = dg_stud.CurrentRowIndex
    '    '    txt_sid.Text = dg_stud.Item(i, 0)
    '    '    txt_name.Text = dg_stud.Item(i, 1)
    '    '    txt_add.Text = dg_stud.Item(i, 2)
    '    '    txt_contact.Text = dg_stud.Item(i, 3)
    '    '    cmb_year.Text = dg_stud.Item(i, 4)
    '    '    cmb_branch.Text = dg_stud.Item(i, 5)


    '    'Catch err As System.Exception

    '    'End Try
    'End Sub

    'Private Sub dg_stud_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_stud.Click
    '    'get_from_grid()
    'End Sub

    'Private Sub dg_stud_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_stud.CurrentCellChanged
    '    ' get_from_grid()
    'End Sub

    'Private Sub btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
    '    'Me.Close()
    'End Sub

    'Private Sub students_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
    '    '  cn.Close()
    'End Sub


    'Private Sub txt_sid_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_sid.LostFocus
    '    If txt_sid.Text <> "" Then
    '        fill_on_keypress()
    '    End If
    'End Sub

    'Private Sub lbl_help_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbl_help.Click
    '    MessageBox.Show("You will have to delete the record to be updated and insert it again with the new information.", "LMS Help", MessageBoxButtons.OK, MessageBoxIcon.Information)
    'End Sub
End Class

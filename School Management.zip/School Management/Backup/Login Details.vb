Public Class Login_Details
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents listlogin As System.Windows.Forms.ListView
    Friend WithEvents btncancel As System.Windows.Forms.Button
    Friend WithEvents btnprint As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.listlogin = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.btncancel = New System.Windows.Forms.Button
        Me.btnprint = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'listlogin
        '
        Me.listlogin.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.listlogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.listlogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listlogin.FullRowSelect = True
        Me.listlogin.GridLines = True
        Me.listlogin.Location = New System.Drawing.Point(0, 24)
        Me.listlogin.Name = "listlogin"
        Me.listlogin.Size = New System.Drawing.Size(688, 424)
        Me.listlogin.TabIndex = 1
        Me.listlogin.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Username"
        Me.ColumnHeader1.Width = 210
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Time Log-In"
        Me.ColumnHeader2.Width = 245
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Time Log-Out"
        Me.ColumnHeader3.Width = 228
        '
        'btncancel
        '
        Me.btncancel.Location = New System.Drawing.Point(592, 464)
        Me.btncancel.Name = "btncancel"
        Me.btncancel.Size = New System.Drawing.Size(75, 32)
        Me.btncancel.TabIndex = 4
        Me.btncancel.Text = "&Cancel"
        '
        'btnprint
        '
        Me.btnprint.Location = New System.Drawing.Point(496, 464)
        Me.btnprint.Name = "btnprint"
        Me.btnprint.Size = New System.Drawing.Size(75, 32)
        Me.btnprint.TabIndex = 3
        Me.btnprint.Text = "&Print"
        '
        'Login_Details
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(688, 510)
        Me.Controls.Add(Me.btncancel)
        Me.Controls.Add(Me.btnprint)
        Me.Controls.Add(Me.listlogin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Login_Details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login_Details"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Login_Details_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        blogind = True
    End Sub

    Private Sub Login_Details_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        blogind = False
    End Sub
End Class

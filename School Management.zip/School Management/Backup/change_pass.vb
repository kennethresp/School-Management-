Imports System.Data.SqlClient

Public Class change_pass
    Inherits System.Windows.Forms.Form
    'Dim cn As New SqlConnection("server=localhost;database=lms;uid=sa;password=;")
    'Dim da As SqlDataAdapter
    'Dim ds As DataSet
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lbl_name As System.Windows.Forms.Label
    Friend WithEvents lbl_studid As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_newpass As System.Windows.Forms.TextBox
    Friend WithEvents txt_oldpass As System.Windows.Forms.TextBox
    Friend WithEvents txt_confirm As System.Windows.Forms.TextBox
    Friend WithEvents btn_ok As System.Windows.Forms.Button
    Friend WithEvents btn_close As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btn_ok = New System.Windows.Forms.Button
        Me.btn_close = New System.Windows.Forms.Button
        Me.lbl_name = New System.Windows.Forms.Label
        Me.txt_newpass = New System.Windows.Forms.TextBox
        Me.lbl_studid = New System.Windows.Forms.Label
        Me.txt_oldpass = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txt_confirm = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'btn_ok
        '
        Me.btn_ok.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_ok.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_ok.Location = New System.Drawing.Point(80, 128)
        Me.btn_ok.Name = "btn_ok"
        Me.btn_ok.Size = New System.Drawing.Size(56, 23)
        Me.btn_ok.TabIndex = 3
        Me.btn_ok.Text = "&OK"
        '
        'btn_close
        '
        Me.btn_close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_close.Location = New System.Drawing.Point(152, 128)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(56, 23)
        Me.btn_close.TabIndex = 4
        Me.btn_close.Text = "&Cancel"
        '
        'lbl_name
        '
        Me.lbl_name.AutoSize = True
        Me.lbl_name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_name.ForeColor = System.Drawing.Color.Navy
        Me.lbl_name.Location = New System.Drawing.Point(19, 57)
        Me.lbl_name.Name = "lbl_name"
        Me.lbl_name.Size = New System.Drawing.Size(95, 17)
        Me.lbl_name.TabIndex = 28
        Me.lbl_name.Text = "New Password :"
        '
        'txt_newpass
        '
        Me.txt_newpass.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_newpass.Location = New System.Drawing.Point(146, 53)
        Me.txt_newpass.MaxLength = 10
        Me.txt_newpass.Name = "txt_newpass"
        Me.txt_newpass.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txt_newpass.Size = New System.Drawing.Size(128, 21)
        Me.txt_newpass.TabIndex = 1
        Me.txt_newpass.Text = ""
        '
        'lbl_studid
        '
        Me.lbl_studid.AutoSize = True
        Me.lbl_studid.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_studid.ForeColor = System.Drawing.Color.Navy
        Me.lbl_studid.Location = New System.Drawing.Point(19, 25)
        Me.lbl_studid.Name = "lbl_studid"
        Me.lbl_studid.Size = New System.Drawing.Size(89, 17)
        Me.lbl_studid.TabIndex = 25
        Me.lbl_studid.Text = "Old Password :"
        '
        'txt_oldpass
        '
        Me.txt_oldpass.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_oldpass.Location = New System.Drawing.Point(146, 21)
        Me.txt_oldpass.MaxLength = 10
        Me.txt_oldpass.Name = "txt_oldpass"
        Me.txt_oldpass.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txt_oldpass.Size = New System.Drawing.Size(128, 21)
        Me.txt_oldpass.TabIndex = 0
        Me.txt_oldpass.Text = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(19, 89)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 17)
        Me.Label6.TabIndex = 33
        Me.Label6.Text = "Re-enter Password :"
        '
        'txt_confirm
        '
        Me.txt_confirm.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_confirm.Location = New System.Drawing.Point(146, 85)
        Me.txt_confirm.MaxLength = 10
        Me.txt_confirm.Name = "txt_confirm"
        Me.txt_confirm.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txt_confirm.Size = New System.Drawing.Size(128, 21)
        Me.txt_confirm.TabIndex = 2
        Me.txt_confirm.Text = ""
        '
        'change_pass
        '
        Me.AcceptButton = Me.btn_ok
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(296, 173)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_confirm)
        Me.Controls.Add(Me.btn_ok)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.lbl_name)
        Me.Controls.Add(Me.txt_newpass)
        Me.Controls.Add(Me.lbl_studid)
        Me.Controls.Add(Me.txt_oldpass)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "change_pass"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Change Password"
        Me.ResumeLayout(False)

    End Sub

#End Region


    'Private Sub btn_ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ok.Click
    '    Try
    '        'all passwords are provided
    '        If txt_oldpass.Text <> "" AndAlso txt_newpass.Text <> "" AndAlso txt_confirm.Text <> "" Then
    '            update_pass()
    '        Else 'one or more passwords is not provided 
    '            MessageBox.Show("All field are mandatory to fill.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '            txt_oldpass.Focus()
    '        End If


    '    Catch err As System.Exception
    '        MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    End Try
    'End Sub

    'Private Function validate_old_password() As Integer

    '    Try
    '        da = New SqlDataAdapter("select Pwd from user_auth", cn)
    '        ds = New DataSet

    '        'fetching user information from database
    '        da.Fill(ds, "user_auth")

    '        'checking password
    '        If txt_oldpass.Text = ds.Tables(0).Rows(0)(0) Then
    '            Return 1
    '        Else
    '            Return 0
    '        End If


    '    Catch ers As SqlException
    '        MessageBox.Show(ers.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    Catch err As System.Exception
    '        MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    Finally

    '        'dereferencing objects
    '        da = Nothing
    '        ds = Nothing


    '    End Try

    'End Function

    'Sub update_pass()
    '    Try

    '        Dim i As Short

    '        i = validate_old_password() 'checking old password

    '        If i = 1 Then 'old password matches.

    '            If txt_newpass.Text = txt_confirm.Text Then 'new passwords are same
    '                Dim cmd As New SqlCommand
    '                cmd.CommandText = "update user_auth set pwd='" & txt_newpass.Text & "' where Usr_name='Librarian'"
    '                cmd.Connection = cn
    '                cmd.ExecuteNonQuery()
    '                cmd = Nothing
    '                MessageBox.Show("Passwords successfully changed !!!", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '                Me.Close()

    '            Else 'new passwords are different
    '                MessageBox.Show("New passwords do not match.", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '            End If

    '        Else 'ols password does not match
    '            MessageBox.Show("Old password does not match.", "LMS", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End If

    '    Catch ers As SqlException
    '        MessageBox.Show(ers.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

    '    Catch err As System.Exception
    '        MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)


    '    End Try

    'End Sub
    'Private Sub btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
    '    Me.Close()
    'End Sub

    'Private Sub txt_newpass_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_newpass.GotFocus
    '    txt_newpass.SelectAll()
    'End Sub
    'Private Sub txt_oldpass_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_oldpass.GotFocus
    '    txt_oldpass.SelectAll()
    'End Sub

    'Private Sub txt_confirm_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_confirm.GotFocus
    '    txt_confirm.SelectAll()
    'End Sub

    'Private Sub change_pass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    '    Try
    '        cn.Open()
    '    Catch ex As SqlException
    '        MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        Me.Close()
    '    End Try
    'End Sub

    'Private Sub change_pass_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
    '    cn.Close()
    'End Sub
End Class

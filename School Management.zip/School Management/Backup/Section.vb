Public Class Section
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picStudent As System.Windows.Forms.PictureBox
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents bttnRemove As System.Windows.Forms.Button
    Friend WithEvents bttnAddNew As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents listsubject As System.Windows.Forms.ListView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Section))
        Me.picStudent = New System.Windows.Forms.PictureBox
        Me.bttnCancel = New System.Windows.Forms.Button
        Me.bttnRemove = New System.Windows.Forms.Button
        Me.bttnAddNew = New System.Windows.Forms.Button
        Me.listsubject = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.SuspendLayout()
        '
        'picStudent
        '
        Me.picStudent.BackColor = System.Drawing.SystemColors.Control
        Me.picStudent.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picStudent.Image = CType(resources.GetObject("picStudent.Image"), System.Drawing.Image)
        Me.picStudent.Location = New System.Drawing.Point(8, 144)
        Me.picStudent.Name = "picStudent"
        Me.picStudent.Size = New System.Drawing.Size(64, 64)
        Me.picStudent.TabIndex = 124
        Me.picStudent.TabStop = False
        '
        'bttnCancel
        '
        Me.bttnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.bttnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnCancel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnCancel.Location = New System.Drawing.Point(8, 88)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(72, 40)
        Me.bttnCancel.TabIndex = 123
        Me.bttnCancel.Text = "&Cancel"
        '
        'bttnRemove
        '
        Me.bttnRemove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnRemove.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnRemove.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnRemove.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnRemove.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnRemove.Location = New System.Drawing.Point(8, 48)
        Me.bttnRemove.Name = "bttnRemove"
        Me.bttnRemove.Size = New System.Drawing.Size(72, 40)
        Me.bttnRemove.TabIndex = 122
        Me.bttnRemove.Text = "&Remove"
        '
        'bttnAddNew
        '
        Me.bttnAddNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnAddNew.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnAddNew.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnAddNew.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnAddNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnAddNew.Location = New System.Drawing.Point(8, 8)
        Me.bttnAddNew.Name = "bttnAddNew"
        Me.bttnAddNew.Size = New System.Drawing.Size(72, 40)
        Me.bttnAddNew.TabIndex = 121
        Me.bttnAddNew.Text = "&Add New"
        '
        'listsubject
        '
        Me.listsubject.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.listsubject.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listsubject.FullRowSelect = True
        Me.listsubject.GridLines = True
        Me.listsubject.Location = New System.Drawing.Point(96, 0)
        Me.listsubject.Name = "listsubject"
        Me.listsubject.Size = New System.Drawing.Size(176, 224)
        Me.listsubject.TabIndex = 125
        Me.listsubject.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "List Of Section"
        Me.ColumnHeader1.Width = 172
        '
        'Section
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(274, 222)
        Me.Controls.Add(Me.listsubject)
        Me.Controls.Add(Me.picStudent)
        Me.Controls.Add(Me.bttnCancel)
        Me.Controls.Add(Me.bttnRemove)
        Me.Controls.Add(Me.bttnAddNew)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Section"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Section"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Section_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bsection = True
        Dim filllist As New fillreader
        filllist.readrdr("tblsubject", conn, listsubject, "subjectName")
    End Sub

    Private Sub Section_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bsection = False
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listsubject.SelectedIndexChanged

    End Sub

    Private Sub bttnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnAddNew.Click
        If badds = False Then
            Dim addsub As New Addnewsubject
            addsub.Show()
        End If
    End Sub

    Private Sub bttnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnRemove.Click
        Dim i As String = listsubject.SelectedItems(0).Text
        Dim squery As String = "Delete from tblsubject where subjectName='" + i + "'"
        If listsubject.SelectedItems.Count = Nothing Then
            MsgBox("plz Select a Subject name to remove", MsgBoxStyle.Exclamation)
        Else
            Dim ds As DialogResult
            ds = MsgBox("Are you Sure to want to Remove This Subject", MsgBoxStyle.OKCancel)
            If ds = DialogResult.OK Then
                Dim removeclass As New clsschmngt("tblsubject", squery)
                MsgBox("Subject Removed Successfullyy..")
                listsubject.SelectedItems(0).Remove()
            End If
        End If
    End Sub
End Class

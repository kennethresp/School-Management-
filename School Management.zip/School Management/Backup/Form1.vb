Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem22 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem23 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem25 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem26 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem27 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem34 As System.Windows.Forms.MenuItem
    Public WithEvents toolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents tlSchoolInfo As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlUsers As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlLogin As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlsep1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlModifyStudents As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlSchoolYear As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlLevel As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlSections As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlsep2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlPopulation As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlsep3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents tlHelp As System.Windows.Forms.ToolBarButton
    Friend WithEvents i32x32 As System.Windows.Forms.ImageList
    Friend WithEvents MenuItem35 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem42 As System.Windows.Forms.MenuItem
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents StatusBarPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem38 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem35 = New System.Windows.Forms.MenuItem
        Me.MenuItem38 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem22 = New System.Windows.Forms.MenuItem
        Me.MenuItem23 = New System.Windows.Forms.MenuItem
        Me.MenuItem24 = New System.Windows.Forms.MenuItem
        Me.MenuItem25 = New System.Windows.Forms.MenuItem
        Me.MenuItem26 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem27 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem42 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem34 = New System.Windows.Forms.MenuItem
        Me.toolBar1 = New System.Windows.Forms.ToolBar
        Me.tlSchoolInfo = New System.Windows.Forms.ToolBarButton
        Me.tlUsers = New System.Windows.Forms.ToolBarButton
        Me.tlLogin = New System.Windows.Forms.ToolBarButton
        Me.tlsep1 = New System.Windows.Forms.ToolBarButton
        Me.tlModifyStudents = New System.Windows.Forms.ToolBarButton
        Me.tlSchoolYear = New System.Windows.Forms.ToolBarButton
        Me.tlLevel = New System.Windows.Forms.ToolBarButton
        Me.tlSections = New System.Windows.Forms.ToolBarButton
        Me.tlsep2 = New System.Windows.Forms.ToolBarButton
        Me.tlPopulation = New System.Windows.Forms.ToolBarButton
        Me.tlsep3 = New System.Windows.Forms.ToolBarButton
        Me.tlHelp = New System.Windows.Forms.ToolBarButton
        Me.i32x32 = New System.Windows.Forms.ImageList(Me.components)
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.StatusBarPanel1 = New System.Windows.Forms.StatusBarPanel
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem35, Me.MenuItem3, Me.MenuItem4, Me.MenuItem42, Me.MenuItem6})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem7, Me.MenuItem12, Me.MenuItem13, Me.MenuItem14})
        Me.MenuItem1.Text = "&File"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 0
        Me.MenuItem7.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem8, Me.MenuItem9, Me.MenuItem10, Me.MenuItem11})
        Me.MenuItem7.Text = "Administrator Option"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 0
        Me.MenuItem8.Text = "School Info"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 1
        Me.MenuItem9.Text = "-"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 2
        Me.MenuItem10.Text = "User Records"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 3
        Me.MenuItem11.Text = "Login Details"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 1
        Me.MenuItem12.Text = "-"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 2
        Me.MenuItem13.Text = "Lock Appliction"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 3
        Me.MenuItem14.Text = "Exit Application"
        '
        'MenuItem35
        '
        Me.MenuItem35.Index = 1
        Me.MenuItem35.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem38, Me.MenuItem17})
        Me.MenuItem35.Text = "Fees Gateway"
        '
        'MenuItem38
        '
        Me.MenuItem38.Index = 0
        Me.MenuItem38.Text = "Deposit Fees"
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 1
        Me.MenuItem17.Text = "Due Fees"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem22, Me.MenuItem23, Me.MenuItem24, Me.MenuItem25, Me.MenuItem26})
        Me.MenuItem3.Text = "&Records"
        '
        'MenuItem22
        '
        Me.MenuItem22.Index = 0
        Me.MenuItem22.Text = "Modify/Add Student Records"
        '
        'MenuItem23
        '
        Me.MenuItem23.Index = 1
        Me.MenuItem23.Text = "-"
        '
        'MenuItem24
        '
        Me.MenuItem24.Index = 2
        Me.MenuItem24.Text = "School Year"
        '
        'MenuItem25
        '
        Me.MenuItem25.Index = 3
        Me.MenuItem25.Text = "Level"
        '
        'MenuItem26
        '
        Me.MenuItem26.Index = 4
        Me.MenuItem26.Text = "Sections"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 3
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem27, Me.MenuItem2})
        Me.MenuItem4.Text = "Fees"
        '
        'MenuItem27
        '
        Me.MenuItem27.Index = 0
        Me.MenuItem27.Text = "Fees Schedule"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "Fees Due Report"
        '
        'MenuItem42
        '
        Me.MenuItem42.Index = 4
        Me.MenuItem42.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem15, Me.MenuItem16})
        Me.MenuItem42.Text = "&Library"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.Text = "Transaction"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 1
        Me.MenuItem15.Text = "Book Master"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 2
        Me.MenuItem16.Text = "Book Due Report"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 5
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem34})
        Me.MenuItem6.Text = "&Help"
        '
        'MenuItem34
        '
        Me.MenuItem34.Index = 0
        Me.MenuItem34.Text = "About School Management System"
        '
        'toolBar1
        '
        Me.toolBar1.AllowDrop = True
        Me.toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat
        Me.toolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.tlSchoolInfo, Me.tlUsers, Me.tlLogin, Me.tlsep1, Me.tlModifyStudents, Me.tlSchoolYear, Me.tlLevel, Me.tlSections, Me.tlsep2, Me.tlPopulation, Me.tlsep3, Me.tlHelp})
        Me.toolBar1.ButtonSize = New System.Drawing.Size(32, 32)
        Me.toolBar1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.toolBar1.DropDownArrows = True
        Me.toolBar1.ImageList = Me.i32x32
        Me.toolBar1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.toolBar1.Location = New System.Drawing.Point(0, 0)
        Me.toolBar1.Name = "toolBar1"
        Me.toolBar1.ShowToolTips = True
        Me.toolBar1.Size = New System.Drawing.Size(800, 44)
        Me.toolBar1.TabIndex = 3
        '
        'tlSchoolInfo
        '
        Me.tlSchoolInfo.ImageIndex = 0
        Me.tlSchoolInfo.ToolTipText = "School Information"
        '
        'tlUsers
        '
        Me.tlUsers.ImageIndex = 1
        Me.tlUsers.ToolTipText = "Users Records"
        '
        'tlLogin
        '
        Me.tlLogin.ImageIndex = 2
        Me.tlLogin.ToolTipText = "Log-in Details"
        '
        'tlsep1
        '
        Me.tlsep1.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'tlModifyStudents
        '
        Me.tlModifyStudents.ImageIndex = 3
        Me.tlModifyStudents.ToolTipText = "Modify Students Records"
        '
        'tlSchoolYear
        '
        Me.tlSchoolYear.ImageIndex = 4
        Me.tlSchoolYear.ToolTipText = "School Year"
        '
        'tlLevel
        '
        Me.tlLevel.ImageIndex = 7
        Me.tlLevel.ToolTipText = "Level"
        '
        'tlSections
        '
        Me.tlSections.ImageIndex = 6
        Me.tlSections.ToolTipText = "Sections"
        '
        'tlsep2
        '
        Me.tlsep2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'tlPopulation
        '
        Me.tlPopulation.ImageIndex = 8
        Me.tlPopulation.ToolTipText = "Population Report"
        '
        'tlsep3
        '
        Me.tlsep3.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'tlHelp
        '
        Me.tlHelp.ImageIndex = 9
        Me.tlHelp.ToolTipText = "Help"
        '
        'i32x32
        '
        Me.i32x32.ImageSize = New System.Drawing.Size(32, 32)
        Me.i32x32.ImageStream = CType(resources.GetObject("i32x32.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.i32x32.TransparentColor = System.Drawing.Color.Transparent
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 480)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel1})
        Me.StatusBar1.Size = New System.Drawing.Size(800, 22)
        Me.StatusBar1.TabIndex = 5
        Me.StatusBar1.Text = "StatusBar1"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(800, 502)
        Me.Controls.Add(Me.StatusBar1)
        Me.Controls.Add(Me.toolBar1)
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        If bschool = False Then
            mdlschool = New School_Info
            mdlschool.MdiParent = Me
            mdlschool.Show()
        End If
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        If buserrec = False Then
            mdluserrec = New User_Records
            mdluserrec.MdiParent = Me
            mdluserrec.Show()
        End If
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        If blogind = False Then
            mdllogind = New Login_Details
            mdllogind.MdiParent = Me
            mdllogind.Show()
        End If
    End Sub

    Private Sub MenuItem22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem22.Click
        If bviewy = False Then
            mdlviewy = New View_year
            mdlviewy.MdiParent = Me
            mdlviewy.Show()
        End If
    End Sub

    Private Sub MenuItem24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem24.Click
        If bmodify = False Then
            mdladdschyear = New Add_School_Year
            mdladdschyear.MdiParent = Me
            mdladdschyear.Show()
        End If
    End Sub

    Private Sub MenuItem25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem25.Click
        If blevel = False Then
            mdllevel = New Frmnewclass
            mdllevel.MdiParent = Me
            mdllevel.Show()
        End If
    End Sub

    Private Sub MenuItem26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem26.Click
        If bsection = False Then
            mdlsection = New Section
            mdlsection.MdiParent = Me
            mdlsection.Show()
        End If
    End Sub

    Private Sub MenuItem34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem34.Click
        If babout = False Then
            mdlabout = New Aboutus
            mdlabout.MdiParent = Me
            mdlabout.Show()
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If blogin = False Then
                mdllogin = New Login
                mdllogin.ShowDialog()
            End If
            'StatusBar1.Panels(1).Text = Date.Today.ToShortDateString
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        schyear = "welcome"
    End Sub

    Private Sub toolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar1.ButtonClick
        If e.Button Is tlSchoolInfo Then
            MenuItem8.PerformClick()
        ElseIf e.Button Is tlUsers Then
            MenuItem10.PerformClick()
        ElseIf e.Button Is tlLogin Then
            MenuItem11.PerformClick()
        ElseIf e.Button Is tlModifyStudents Then
            MenuItem22.PerformClick()
        ElseIf e.Button Is tlSchoolYear Then
            MenuItem24.PerformClick()
        ElseIf e.Button Is tlLevel Then
            MenuItem25.PerformClick()
        ElseIf e.Button Is tlPopulation Then
            MenuItem27.PerformClick()
        ElseIf e.Button Is tlHelp Then
            MenuItem34.PerformClick()
        End If
    End Sub
    Private Sub MenuItem33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If bclndr = False Then
            bcalendar = New Calender
            bcalendar.MdiParent = Me
            bcalendar.Show()
        End If
    End Sub
    Private Sub MenuItem38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem38.Click
        If bbooks = False Then
            mdlbooks = New books
            mdlbooks.MdiParent = Me
            mdlbooks.Show()
        End If
    End Sub

    Private Sub MenuItem36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If btran = False Then
            mdltran = New transaction
            mdltran.MdiParent = Me
            mdltran.Show()
        End If
    End Sub

    Private Sub MenuItem41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If bchangepass = False Then
            mdlchangepass = New change_pass
            mdlchangepass.MdiParent = Me
            mdlchangepass.Show()
        End If

    End Sub

    Private Sub MenuItem43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If breport = False Then
            mdlreport = New report
            mdlreport.MdiParent = Me
            mdlreport.Show()
        End If
    End Sub
    Private Sub MenuItem14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem14.Click
        End
    End Sub

    Private Sub MenuItem42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem42.Click

    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click

    End Sub

    Private Sub MenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem15.Click
        If bbooks = False Then
            mdlbooks = New books
            mdlbooks.MdiParent = Me
            mdlbooks.Show()
        End If
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        If btran = False Then
            mdltran = New transaction
            mdltran.MdiParent = Me
            mdltran.Show()
        End If
    End Sub

    Private Sub MenuItem27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem27.Click
        If bfee_s = False Then
            mdlfee_s = New feesschedule
            mdlfee_s.MdiParent = Me
            mdlfee_s.Show()
        End If
    End Sub
End Class

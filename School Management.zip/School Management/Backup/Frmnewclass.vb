Public Class Frmnewclass
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents chLevelName As System.Windows.Forms.ColumnHeader
    Friend WithEvents picStudent As System.Windows.Forms.PictureBox
    Friend WithEvents bttnRemove As System.Windows.Forms.Button
    Friend WithEvents bttnAddNew As System.Windows.Forms.Button
    Friend WithEvents listlevel As System.Windows.Forms.ListView
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Frmnewclass))
        Me.bttnCancel = New System.Windows.Forms.Button
        Me.chLevelName = New System.Windows.Forms.ColumnHeader
        Me.picStudent = New System.Windows.Forms.PictureBox
        Me.bttnRemove = New System.Windows.Forms.Button
        Me.bttnAddNew = New System.Windows.Forms.Button
        Me.listlevel = New System.Windows.Forms.ListView
        Me.SuspendLayout()
        '
        'bttnCancel
        '
        Me.bttnCancel.BackColor = System.Drawing.SystemColors.Control
        Me.bttnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnCancel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnCancel.Location = New System.Drawing.Point(0, 80)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(72, 40)
        Me.bttnCancel.TabIndex = 122
        Me.bttnCancel.Text = "&Cancel"
        '
        'chLevelName
        '
        Me.chLevelName.Text = "Class Name"
        Me.chLevelName.Width = 170
        '
        'picStudent
        '
        Me.picStudent.BackColor = System.Drawing.SystemColors.Control
        Me.picStudent.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picStudent.Image = CType(resources.GetObject("picStudent.Image"), System.Drawing.Image)
        Me.picStudent.Location = New System.Drawing.Point(3, 144)
        Me.picStudent.Name = "picStudent"
        Me.picStudent.Size = New System.Drawing.Size(64, 64)
        Me.picStudent.TabIndex = 123
        Me.picStudent.TabStop = False
        '
        'bttnRemove
        '
        Me.bttnRemove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnRemove.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnRemove.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnRemove.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnRemove.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnRemove.Location = New System.Drawing.Point(0, 40)
        Me.bttnRemove.Name = "bttnRemove"
        Me.bttnRemove.Size = New System.Drawing.Size(72, 40)
        Me.bttnRemove.TabIndex = 121
        Me.bttnRemove.Text = "&Remove"
        '
        'bttnAddNew
        '
        Me.bttnAddNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnAddNew.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnAddNew.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnAddNew.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnAddNew.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnAddNew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnAddNew.Location = New System.Drawing.Point(0, 0)
        Me.bttnAddNew.Name = "bttnAddNew"
        Me.bttnAddNew.Size = New System.Drawing.Size(72, 40)
        Me.bttnAddNew.TabIndex = 120
        Me.bttnAddNew.Text = "&Add New"
        '
        'listlevel
        '
        Me.listlevel.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chLevelName})
        Me.listlevel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.listlevel.Dock = System.Windows.Forms.DockStyle.Right
        Me.listlevel.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.listlevel.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.listlevel.FullRowSelect = True
        Me.listlevel.GridLines = True
        Me.listlevel.Location = New System.Drawing.Point(72, 0)
        Me.listlevel.Name = "listlevel"
        Me.listlevel.Size = New System.Drawing.Size(200, 238)
        Me.listlevel.TabIndex = 119
        Me.listlevel.View = System.Windows.Forms.View.Details
        '
        'Frmnewclass
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 238)
        Me.Controls.Add(Me.bttnCancel)
        Me.Controls.Add(Me.picStudent)
        Me.Controls.Add(Me.bttnRemove)
        Me.Controls.Add(Me.bttnAddNew)
        Me.Controls.Add(Me.listlevel)
        Me.Name = "Frmnewclass"
        Me.Text = "Frmnewclass"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub bttnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnAddNew.Click
        If baddc = False Then
            Dim addclass As New Addnewclass
            addclass.Show()
        End If
    End Sub

    Private Sub Frmnewclass_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim filllist As New fillreader
        filllist.readrdr("tblclass", conn, listlevel, "className")

    End Sub

    Private Sub bttnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnCancel.Click
        Me.Close()
    End Sub

    Private Sub bttnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bttnRemove.Click
        Dim i As String = listlevel.SelectedItems(0).Text
        Dim squery As String = "Delete from tblclass where className='" + i + "'"
        If listlevel.SelectedItems.Count = Nothing Then
            MsgBox("plz Select a Class name to remove", MsgBoxStyle.Exclamation)
        Else
            Dim ds As DialogResult
            ds = MsgBox("Are you Sure to want to Remove This Class", MsgBoxStyle.OKCancel)
            If ds = DialogResult.OK Then
                Dim removeclass As New clsschmngt("tblclass", squery)
                MsgBox("Class Removed Successfullyy..")
                listlevel.SelectedItems(0).Remove()
            End If
        End If
    End Sub
End Class

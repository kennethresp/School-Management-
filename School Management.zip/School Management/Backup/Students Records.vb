Public Class Students_Records
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents tabControl As System.Windows.Forms.TabControl
    Friend WithEvents tabList As System.Windows.Forms.TabPage
    Public WithEvents lvStudents As System.Windows.Forms.ListView
    Public WithEvents tabSections As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents tabInformation As System.Windows.Forms.TabPage
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtDateEnrolled As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtBDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtLastSchoolAttend As System.Windows.Forms.TextBox
    Friend WithEvents txtMOccupation As System.Windows.Forms.TextBox
    Friend WithEvents txtFOccupation As System.Windows.Forms.TextBox
    Friend WithEvents txtParentAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtMotherName As System.Windows.Forms.TextBox
    Friend WithEvents txtFatherName As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtBPlace As System.Windows.Forms.TextBox
    Friend WithEvents txtAge As System.Windows.Forms.TextBox
    Friend WithEvents txtGender As System.Windows.Forms.TextBox
    Friend WithEvents txtStudentName As System.Windows.Forms.TextBox
    Friend WithEvents txtStudentNo As System.Windows.Forms.TextBox
    Friend WithEvents picStudent As System.Windows.Forms.PictureBox
    Friend WithEvents label18 As System.Windows.Forms.Label
    Friend WithEvents label17 As System.Windows.Forms.Label
    Friend WithEvents label16 As System.Windows.Forms.Label
    Friend WithEvents label15 As System.Windows.Forms.Label
    Friend WithEvents label14 As System.Windows.Forms.Label
    Friend WithEvents label12 As System.Windows.Forms.Label
    Friend WithEvents label13 As System.Windows.Forms.Label
    Friend WithEvents label11 As System.Windows.Forms.Label
    Friend WithEvents label9 As System.Windows.Forms.Label
    Friend WithEvents label10 As System.Windows.Forms.Label
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents chNo As System.Windows.Forms.ColumnHeader
    Friend WithEvents chFullname As System.Windows.Forms.ColumnHeader
    Friend WithEvents chGender As System.Windows.Forms.ColumnHeader
    Friend WithEvents chAddress As System.Windows.Forms.ColumnHeader
    Friend WithEvents bttnPrint As System.Windows.Forms.Button
    Friend WithEvents bttnSearch As System.Windows.Forms.Button
    Friend WithEvents bttnRemove As System.Windows.Forms.Button
    Friend WithEvents bttnCancel As System.Windows.Forms.Button
    Friend WithEvents btnaddnew As System.Windows.Forms.Button
    Friend WithEvents btnmodify As System.Windows.Forms.Button
    Friend WithEvents lblselectedyear As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tabControl = New System.Windows.Forms.TabControl
        Me.tabList = New System.Windows.Forms.TabPage
        Me.lvStudents = New System.Windows.Forms.ListView
        Me.chNo = New System.Windows.Forms.ColumnHeader
        Me.chFullname = New System.Windows.Forms.ColumnHeader
        Me.chGender = New System.Windows.Forms.ColumnHeader
        Me.chAddress = New System.Windows.Forms.ColumnHeader
        Me.tabSections = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.panel1 = New System.Windows.Forms.Panel
        Me.tabInformation = New System.Windows.Forms.TabPage
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.dtDateEnrolled = New System.Windows.Forms.DateTimePicker
        Me.dtBDate = New System.Windows.Forms.DateTimePicker
        Me.txtStatus = New System.Windows.Forms.TextBox
        Me.txtLastSchoolAttend = New System.Windows.Forms.TextBox
        Me.txtMOccupation = New System.Windows.Forms.TextBox
        Me.txtFOccupation = New System.Windows.Forms.TextBox
        Me.txtParentAddress = New System.Windows.Forms.TextBox
        Me.txtMotherName = New System.Windows.Forms.TextBox
        Me.txtFatherName = New System.Windows.Forms.TextBox
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.txtBPlace = New System.Windows.Forms.TextBox
        Me.txtAge = New System.Windows.Forms.TextBox
        Me.txtGender = New System.Windows.Forms.TextBox
        Me.txtStudentName = New System.Windows.Forms.TextBox
        Me.txtStudentNo = New System.Windows.Forms.TextBox
        Me.picStudent = New System.Windows.Forms.PictureBox
        Me.label18 = New System.Windows.Forms.Label
        Me.label17 = New System.Windows.Forms.Label
        Me.label16 = New System.Windows.Forms.Label
        Me.label15 = New System.Windows.Forms.Label
        Me.label14 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.label13 = New System.Windows.Forms.Label
        Me.label11 = New System.Windows.Forms.Label
        Me.label9 = New System.Windows.Forms.Label
        Me.label10 = New System.Windows.Forms.Label
        Me.label8 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.bttnPrint = New System.Windows.Forms.Button
        Me.bttnSearch = New System.Windows.Forms.Button
        Me.bttnRemove = New System.Windows.Forms.Button
        Me.bttnCancel = New System.Windows.Forms.Button
        Me.btnaddnew = New System.Windows.Forms.Button
        Me.btnmodify = New System.Windows.Forms.Button
        Me.lblselectedyear = New System.Windows.Forms.Label
        Me.tabControl.SuspendLayout()
        Me.tabList.SuspendLayout()
        Me.tabSections.SuspendLayout()
        Me.tabInformation.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabControl
        '
        Me.tabControl.Controls.Add(Me.tabList)
        Me.tabControl.Controls.Add(Me.tabInformation)
        Me.tabControl.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tabControl.Dock = System.Windows.Forms.DockStyle.Top
        Me.tabControl.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabControl.Location = New System.Drawing.Point(0, 0)
        Me.tabControl.Name = "tabControl"
        Me.tabControl.SelectedIndex = 0
        Me.tabControl.Size = New System.Drawing.Size(744, 464)
        Me.tabControl.TabIndex = 74
        '
        'tabList
        '
        Me.tabList.Controls.Add(Me.lvStudents)
        Me.tabList.Controls.Add(Me.tabSections)
        Me.tabList.Controls.Add(Me.panel1)
        Me.tabList.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tabList.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.tabList.Location = New System.Drawing.Point(4, 25)
        Me.tabList.Name = "tabList"
        Me.tabList.Size = New System.Drawing.Size(736, 435)
        Me.tabList.TabIndex = 0
        Me.tabList.Text = "Student Records"
        '
        'lvStudents
        '
        Me.lvStudents.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lvStudents.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chNo, Me.chFullname, Me.chGender, Me.chAddress})
        Me.lvStudents.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvStudents.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.lvStudents.FullRowSelect = True
        Me.lvStudents.GridLines = True
        Me.lvStudents.HideSelection = False
        Me.lvStudents.Location = New System.Drawing.Point(8, 40)
        Me.lvStudents.MultiSelect = False
        Me.lvStudents.Name = "lvStudents"
        Me.lvStudents.Size = New System.Drawing.Size(718, 384)
        Me.lvStudents.TabIndex = 67
        Me.lvStudents.View = System.Windows.Forms.View.Details
        '
        'chNo
        '
        Me.chNo.Text = "No"
        Me.chNo.Width = 0
        '
        'chFullname
        '
        Me.chFullname.Text = "Fullname"
        Me.chFullname.Width = 250
        '
        'chGender
        '
        Me.chGender.Text = "Gender"
        Me.chGender.Width = 80
        '
        'chAddress
        '
        Me.chAddress.Text = "Address"
        Me.chAddress.Width = 350
        '
        'tabSections
        '
        Me.tabSections.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabSections.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.tabSections.Controls.Add(Me.tabPage1)
        Me.tabSections.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabSections.Location = New System.Drawing.Point(0, 8)
        Me.tabSections.Name = "tabSections"
        Me.tabSections.SelectedIndex = 0
        Me.tabSections.Size = New System.Drawing.Size(734, 424)
        Me.tabSections.TabIndex = 66
        '
        'tabPage1
        '
        Me.tabPage1.Location = New System.Drawing.Point(4, 28)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(726, 392)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "All Sections"
        '
        'panel1
        '
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panel1.Location = New System.Drawing.Point(0, 395)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(736, 40)
        Me.panel1.TabIndex = 65
        '
        'tabInformation
        '
        Me.tabInformation.Controls.Add(Me.groupBox1)
        Me.tabInformation.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tabInformation.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.tabInformation.Location = New System.Drawing.Point(4, 25)
        Me.tabInformation.Name = "tabInformation"
        Me.tabInformation.Size = New System.Drawing.Size(736, 435)
        Me.tabInformation.TabIndex = 1
        Me.tabInformation.Text = "Student Information"
        Me.tabInformation.Visible = False
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.dtDateEnrolled)
        Me.groupBox1.Controls.Add(Me.dtBDate)
        Me.groupBox1.Controls.Add(Me.txtStatus)
        Me.groupBox1.Controls.Add(Me.txtLastSchoolAttend)
        Me.groupBox1.Controls.Add(Me.txtMOccupation)
        Me.groupBox1.Controls.Add(Me.txtFOccupation)
        Me.groupBox1.Controls.Add(Me.txtParentAddress)
        Me.groupBox1.Controls.Add(Me.txtMotherName)
        Me.groupBox1.Controls.Add(Me.txtFatherName)
        Me.groupBox1.Controls.Add(Me.txtAddress)
        Me.groupBox1.Controls.Add(Me.txtBPlace)
        Me.groupBox1.Controls.Add(Me.txtAge)
        Me.groupBox1.Controls.Add(Me.txtGender)
        Me.groupBox1.Controls.Add(Me.txtStudentName)
        Me.groupBox1.Controls.Add(Me.txtStudentNo)
        Me.groupBox1.Controls.Add(Me.picStudent)
        Me.groupBox1.Controls.Add(Me.label18)
        Me.groupBox1.Controls.Add(Me.label17)
        Me.groupBox1.Controls.Add(Me.label16)
        Me.groupBox1.Controls.Add(Me.label15)
        Me.groupBox1.Controls.Add(Me.label14)
        Me.groupBox1.Controls.Add(Me.label12)
        Me.groupBox1.Controls.Add(Me.label13)
        Me.groupBox1.Controls.Add(Me.label11)
        Me.groupBox1.Controls.Add(Me.label9)
        Me.groupBox1.Controls.Add(Me.label10)
        Me.groupBox1.Controls.Add(Me.label8)
        Me.groupBox1.Controls.Add(Me.label7)
        Me.groupBox1.Controls.Add(Me.label6)
        Me.groupBox1.Controls.Add(Me.label5)
        Me.groupBox1.Controls.Add(Me.label4)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.label1)
        Me.groupBox1.Location = New System.Drawing.Point(8, 16)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(712, 408)
        Me.groupBox1.TabIndex = 0
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "     INFORMATION"
        '
        'dtDateEnrolled
        '
        Me.dtDateEnrolled.CalendarFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtDateEnrolled.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtDateEnrolled.Location = New System.Drawing.Point(120, 332)
        Me.dtDateEnrolled.Name = "dtDateEnrolled"
        Me.dtDateEnrolled.Size = New System.Drawing.Size(216, 22)
        Me.dtDateEnrolled.TabIndex = 134
        '
        'dtBDate
        '
        Me.dtBDate.CalendarFont = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtBDate.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtBDate.Location = New System.Drawing.Point(464, 108)
        Me.dtBDate.Name = "dtBDate"
        Me.dtBDate.Size = New System.Drawing.Size(216, 22)
        Me.dtBDate.TabIndex = 133
        '
        'txtStatus
        '
        Me.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStatus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStatus.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtStatus.Location = New System.Drawing.Point(424, 336)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.ReadOnly = True
        Me.txtStatus.Size = New System.Drawing.Size(272, 15)
        Me.txtStatus.TabIndex = 132
        Me.txtStatus.Text = ""
        '
        'txtLastSchoolAttend
        '
        Me.txtLastSchoolAttend.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtLastSchoolAttend.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastSchoolAttend.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtLastSchoolAttend.Location = New System.Drawing.Point(144, 360)
        Me.txtLastSchoolAttend.Name = "txtLastSchoolAttend"
        Me.txtLastSchoolAttend.ReadOnly = True
        Me.txtLastSchoolAttend.Size = New System.Drawing.Size(552, 15)
        Me.txtLastSchoolAttend.TabIndex = 131
        Me.txtLastSchoolAttend.Text = ""
        '
        'txtMOccupation
        '
        Me.txtMOccupation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtMOccupation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMOccupation.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtMOccupation.Location = New System.Drawing.Point(504, 248)
        Me.txtMOccupation.Name = "txtMOccupation"
        Me.txtMOccupation.ReadOnly = True
        Me.txtMOccupation.Size = New System.Drawing.Size(192, 15)
        Me.txtMOccupation.TabIndex = 129
        Me.txtMOccupation.Text = ""
        '
        'txtFOccupation
        '
        Me.txtFOccupation.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFOccupation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFOccupation.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtFOccupation.Location = New System.Drawing.Point(504, 224)
        Me.txtFOccupation.Name = "txtFOccupation"
        Me.txtFOccupation.ReadOnly = True
        Me.txtFOccupation.Size = New System.Drawing.Size(192, 15)
        Me.txtFOccupation.TabIndex = 128
        Me.txtFOccupation.Text = ""
        '
        'txtParentAddress
        '
        Me.txtParentAddress.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtParentAddress.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtParentAddress.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtParentAddress.Location = New System.Drawing.Point(136, 272)
        Me.txtParentAddress.Name = "txtParentAddress"
        Me.txtParentAddress.ReadOnly = True
        Me.txtParentAddress.Size = New System.Drawing.Size(560, 15)
        Me.txtParentAddress.TabIndex = 127
        Me.txtParentAddress.Text = ""
        '
        'txtMotherName
        '
        Me.txtMotherName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtMotherName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMotherName.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtMotherName.Location = New System.Drawing.Point(136, 248)
        Me.txtMotherName.Name = "txtMotherName"
        Me.txtMotherName.ReadOnly = True
        Me.txtMotherName.Size = New System.Drawing.Size(232, 15)
        Me.txtMotherName.TabIndex = 126
        Me.txtMotherName.Text = ""
        '
        'txtFatherName
        '
        Me.txtFatherName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtFatherName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFatherName.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtFatherName.Location = New System.Drawing.Point(136, 224)
        Me.txtFatherName.Name = "txtFatherName"
        Me.txtFatherName.ReadOnly = True
        Me.txtFatherName.Size = New System.Drawing.Size(232, 15)
        Me.txtFatherName.TabIndex = 125
        Me.txtFatherName.Text = ""
        '
        'txtAddress
        '
        Me.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtAddress.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtAddress.Location = New System.Drawing.Point(136, 160)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.ReadOnly = True
        Me.txtAddress.Size = New System.Drawing.Size(560, 15)
        Me.txtAddress.TabIndex = 124
        Me.txtAddress.Text = ""
        '
        'txtBPlace
        '
        Me.txtBPlace.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtBPlace.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBPlace.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtBPlace.Location = New System.Drawing.Point(104, 136)
        Me.txtBPlace.Name = "txtBPlace"
        Me.txtBPlace.ReadOnly = True
        Me.txtBPlace.Size = New System.Drawing.Size(592, 15)
        Me.txtBPlace.TabIndex = 123
        Me.txtBPlace.Text = ""
        '
        'txtAge
        '
        Me.txtAge.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtAge.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAge.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtAge.Location = New System.Drawing.Point(248, 112)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.ReadOnly = True
        Me.txtAge.Size = New System.Drawing.Size(112, 15)
        Me.txtAge.TabIndex = 121
        Me.txtAge.Text = ""
        '
        'txtGender
        '
        Me.txtGender.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtGender.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGender.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtGender.Location = New System.Drawing.Point(88, 112)
        Me.txtGender.Name = "txtGender"
        Me.txtGender.ReadOnly = True
        Me.txtGender.Size = New System.Drawing.Size(120, 15)
        Me.txtGender.TabIndex = 120
        Me.txtGender.Text = ""
        '
        'txtStudentName
        '
        Me.txtStudentName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStudentName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentName.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtStudentName.Location = New System.Drawing.Point(128, 88)
        Me.txtStudentName.Name = "txtStudentName"
        Me.txtStudentName.ReadOnly = True
        Me.txtStudentName.Size = New System.Drawing.Size(416, 15)
        Me.txtStudentName.TabIndex = 119
        Me.txtStudentName.Text = ""
        '
        'txtStudentNo
        '
        Me.txtStudentNo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtStudentNo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentNo.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.txtStudentNo.Location = New System.Drawing.Point(128, 64)
        Me.txtStudentNo.Name = "txtStudentNo"
        Me.txtStudentNo.ReadOnly = True
        Me.txtStudentNo.Size = New System.Drawing.Size(416, 15)
        Me.txtStudentNo.TabIndex = 118
        Me.txtStudentNo.Text = ""
        '
        'picStudent
        '
        Me.picStudent.BackColor = System.Drawing.Color.White
        Me.picStudent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picStudent.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picStudent.Location = New System.Drawing.Point(592, 24)
        Me.picStudent.Name = "picStudent"
        Me.picStudent.Size = New System.Drawing.Size(88, 72)
        Me.picStudent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picStudent.TabIndex = 117
        Me.picStudent.TabStop = False
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label18.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label18.ForeColor = System.Drawing.Color.Black
        Me.label18.Location = New System.Drawing.Point(16, 40)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(144, 18)
        Me.label18.TabIndex = 17
        Me.label18.Text = "* Student Information"
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label17.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label17.ForeColor = System.Drawing.Color.Black
        Me.label17.Location = New System.Drawing.Point(16, 200)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(135, 18)
        Me.label17.TabIndex = 16
        Me.label17.Text = "* Family Background"
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label16.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label16.ForeColor = System.Drawing.Color.Black
        Me.label16.Location = New System.Drawing.Point(16, 312)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(136, 18)
        Me.label16.TabIndex = 15
        Me.label16.Text = "* School Information"
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.ForeColor = System.Drawing.Color.Black
        Me.label15.Location = New System.Drawing.Point(32, 64)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(60, 18)
        Me.label15.TabIndex = 14
        Me.label15.Text = "Enroll NO:"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label14.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label14.ForeColor = System.Drawing.Color.Black
        Me.label14.Location = New System.Drawing.Point(32, 360)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(111, 18)
        Me.label14.TabIndex = 13
        Me.label14.Text = "Last School Attend:"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label12.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.ForeColor = System.Drawing.Color.Black
        Me.label12.Location = New System.Drawing.Point(376, 336)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(43, 18)
        Me.label12.TabIndex = 12
        Me.label12.Text = "Status:"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label13.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label13.ForeColor = System.Drawing.Color.Black
        Me.label13.Location = New System.Drawing.Point(32, 336)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(82, 18)
        Me.label13.TabIndex = 11
        Me.label13.Text = "Date Enrolled:"
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label11.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.ForeColor = System.Drawing.Color.Black
        Me.label11.Location = New System.Drawing.Point(32, 272)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(97, 18)
        Me.label11.TabIndex = 10
        Me.label11.Text = "Parents Address:"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label9.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label9.ForeColor = System.Drawing.Color.Black
        Me.label9.Location = New System.Drawing.Point(376, 248)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(120, 18)
        Me.label9.TabIndex = 9
        Me.label9.Text = "Mother's Occupation:"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label10.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label10.ForeColor = System.Drawing.Color.Black
        Me.label10.Location = New System.Drawing.Point(32, 248)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(91, 18)
        Me.label10.TabIndex = 8
        Me.label10.Text = "Mother's Name:"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.ForeColor = System.Drawing.Color.Black
        Me.label8.Location = New System.Drawing.Point(376, 224)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(117, 18)
        Me.label8.TabIndex = 7
        Me.label8.Text = "Father's Occupation:"
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.ForeColor = System.Drawing.Color.Black
        Me.label7.Location = New System.Drawing.Point(32, 224)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(87, 18)
        Me.label7.TabIndex = 6
        Me.label7.Text = "Father's Name:"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.label6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.ForeColor = System.Drawing.Color.Black
        Me.label6.Location = New System.Drawing.Point(32, 160)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(97, 18)
        Me.label6.TabIndex = 5
        Me.label6.Text = "Current Address:"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.ForeColor = System.Drawing.Color.Black
        Me.label5.Location = New System.Drawing.Point(32, 136)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(67, 18)
        Me.label5.TabIndex = 4
        Me.label5.Text = "Birth Place:"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.ForeColor = System.Drawing.Color.Black
        Me.label4.Location = New System.Drawing.Point(400, 112)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(64, 18)
        Me.label4.TabIndex = 3
        Me.label4.Text = "Birth Date:"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.ForeColor = System.Drawing.Color.Black
        Me.label3.Location = New System.Drawing.Point(216, 112)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(30, 18)
        Me.label3.TabIndex = 2
        Me.label3.Text = "Age:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label2.ForeColor = System.Drawing.Color.Black
        Me.label2.Location = New System.Drawing.Point(32, 112)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(48, 18)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Gender:"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.ForeColor = System.Drawing.Color.Black
        Me.label1.Location = New System.Drawing.Point(32, 88)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(87, 18)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Student Name:"
        '
        'bttnPrint
        '
        Me.bttnPrint.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnPrint.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnPrint.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnPrint.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnPrint.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnPrint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnPrint.Location = New System.Drawing.Point(296, 480)
        Me.bttnPrint.Name = "bttnPrint"
        Me.bttnPrint.Size = New System.Drawing.Size(104, 32)
        Me.bttnPrint.TabIndex = 78
        Me.bttnPrint.Text = "&Print"
        '
        'bttnSearch
        '
        Me.bttnSearch.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnSearch.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnSearch.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnSearch.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnSearch.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnSearch.Location = New System.Drawing.Point(400, 480)
        Me.bttnSearch.Name = "bttnSearch"
        Me.bttnSearch.Size = New System.Drawing.Size(104, 32)
        Me.bttnSearch.TabIndex = 77
        Me.bttnSearch.Text = "&Search"
        '
        'bttnRemove
        '
        Me.bttnRemove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnRemove.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnRemove.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnRemove.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnRemove.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnRemove.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnRemove.Location = New System.Drawing.Point(504, 480)
        Me.bttnRemove.Name = "bttnRemove"
        Me.bttnRemove.Size = New System.Drawing.Size(104, 32)
        Me.bttnRemove.TabIndex = 76
        Me.bttnRemove.Text = "&Remove"
        '
        'bttnCancel
        '
        Me.bttnCancel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.bttnCancel.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.bttnCancel.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bttnCancel.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.bttnCancel.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.bttnCancel.Location = New System.Drawing.Point(608, 480)
        Me.bttnCancel.Name = "bttnCancel"
        Me.bttnCancel.Size = New System.Drawing.Size(104, 32)
        Me.bttnCancel.TabIndex = 75
        Me.bttnCancel.Text = "&Cancel"
        '
        'btnaddnew
        '
        Me.btnaddnew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnaddnew.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnaddnew.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnaddnew.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddnew.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.btnaddnew.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnaddnew.Location = New System.Drawing.Point(88, 480)
        Me.btnaddnew.Name = "btnaddnew"
        Me.btnaddnew.Size = New System.Drawing.Size(104, 32)
        Me.btnaddnew.TabIndex = 80
        Me.btnaddnew.Text = "&Add New"
        '
        'btnmodify
        '
        Me.btnmodify.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnmodify.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnmodify.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnmodify.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnmodify.ForeColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.btnmodify.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.btnmodify.Location = New System.Drawing.Point(192, 480)
        Me.btnmodify.Name = "btnmodify"
        Me.btnmodify.Size = New System.Drawing.Size(104, 32)
        Me.btnmodify.TabIndex = 79
        Me.btnmodify.Text = "&Modify"
        '
        'lblselectedyear
        '
        Me.lblselectedyear.Location = New System.Drawing.Point(24, 488)
        Me.lblselectedyear.Name = "lblselectedyear"
        Me.lblselectedyear.Size = New System.Drawing.Size(48, 24)
        Me.lblselectedyear.TabIndex = 81
        Me.lblselectedyear.Text = "lbl"
        '
        'Students_Records
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(744, 518)
        Me.Controls.Add(Me.lblselectedyear)
        Me.Controls.Add(Me.bttnPrint)
        Me.Controls.Add(Me.bttnSearch)
        Me.Controls.Add(Me.bttnRemove)
        Me.Controls.Add(Me.bttnCancel)
        Me.Controls.Add(Me.btnaddnew)
        Me.Controls.Add(Me.btnmodify)
        Me.Controls.Add(Me.tabControl)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Students_Records"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Students_Records"
        Me.tabControl.ResumeLayout(False)
        Me.tabList.ResumeLayout(False)
        Me.tabSections.ResumeLayout(False)
        Me.tabInformation.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub tabList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tabList.Click

    End Sub
    Dim c As Integer
    '    Dim d As Integer
    Private Sub Students_Records_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        bstudrec = True
        Dim cmd As New OleDb.OleDbCommand("Select Name, Gender, Address from tblStudentsRecords where SchoolYear='" + lblselectedyear.Text.Trim + "'", conn)
        conn.Open()
        Try
            Dim readr As OleDb.OleDbDataReader = cmd.ExecuteReader
            If readr.HasRows Then

                While readr.Read
                    For c = 0 To readr.FieldCount - 1
                        lvStudents.Items.Add(readr.GetString(c))
                    Next
                End While
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

    Private Sub Students_Records_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        bstudrec = False
    End Sub


    Private Sub btnaddnew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddnew.Click
        If bmstudr = False Then
            mdlmstudr = New Modify_Student_Records
            mdlmstudr.Show()
            mdlmstudr.Text = "Add New Student"
            mdlmstudr.btnupdate.Text = "Add"
            mdlmstudr.lblselectedyear.Text = lblselectedyear.Text
        End If
    End Sub
End Class

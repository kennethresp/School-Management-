Imports System.Data.OleDb

Public Class books
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lbl_bookid As System.Windows.Forms.Label
    Friend WithEvents lbl_title As System.Windows.Forms.Label
    Friend WithEvents lbl_author As System.Windows.Forms.Label
    Friend WithEvents lbl_pub As System.Windows.Forms.Label
    Friend WithEvents lbl_Price As System.Windows.Forms.Label
    Friend WithEvents dg_books As System.Windows.Forms.DataGrid
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_add As System.Windows.Forms.Button
    Friend WithEvents btn_remove As System.Windows.Forms.Button
    Friend WithEvents btn_close As System.Windows.Forms.Button
    Friend WithEvents txt_bookid As System.Windows.Forms.TextBox
    Friend WithEvents txt_booktitle As System.Windows.Forms.TextBox
    Friend WithEvents txt_author As System.Windows.Forms.TextBox
    Friend WithEvents txt_pub As System.Windows.Forms.TextBox
    Friend WithEvents txt_price As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lbl_bookid = New System.Windows.Forms.Label
        Me.lbl_title = New System.Windows.Forms.Label
        Me.lbl_author = New System.Windows.Forms.Label
        Me.lbl_pub = New System.Windows.Forms.Label
        Me.lbl_Price = New System.Windows.Forms.Label
        Me.txt_bookid = New System.Windows.Forms.TextBox
        Me.txt_booktitle = New System.Windows.Forms.TextBox
        Me.txt_author = New System.Windows.Forms.TextBox
        Me.txt_pub = New System.Windows.Forms.TextBox
        Me.txt_price = New System.Windows.Forms.TextBox
        Me.dg_books = New System.Windows.Forms.DataGrid
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btn_add = New System.Windows.Forms.Button
        Me.btn_remove = New System.Windows.Forms.Button
        Me.btn_close = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        CType(Me.dg_books, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_bookid
        '
        Me.lbl_bookid.AutoSize = True
        Me.lbl_bookid.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_bookid.Location = New System.Drawing.Point(16, 37)
        Me.lbl_bookid.Name = "lbl_bookid"
        Me.lbl_bookid.Size = New System.Drawing.Size(56, 17)
        Me.lbl_bookid.TabIndex = 0
        Me.lbl_bookid.Text = "BookId : "
        '
        'lbl_title
        '
        Me.lbl_title.AutoSize = True
        Me.lbl_title.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_title.Location = New System.Drawing.Point(16, 77)
        Me.lbl_title.Name = "lbl_title"
        Me.lbl_title.Size = New System.Drawing.Size(37, 17)
        Me.lbl_title.TabIndex = 1
        Me.lbl_title.Text = "Title :"
        '
        'lbl_author
        '
        Me.lbl_author.AutoSize = True
        Me.lbl_author.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_author.Location = New System.Drawing.Point(16, 117)
        Me.lbl_author.Name = "lbl_author"
        Me.lbl_author.Size = New System.Drawing.Size(54, 17)
        Me.lbl_author.TabIndex = 2
        Me.lbl_author.Text = "Author : "
        '
        'lbl_pub
        '
        Me.lbl_pub.AutoSize = True
        Me.lbl_pub.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_pub.Location = New System.Drawing.Point(16, 160)
        Me.lbl_pub.Name = "lbl_pub"
        Me.lbl_pub.Size = New System.Drawing.Size(52, 17)
        Me.lbl_pub.TabIndex = 3
        Me.lbl_pub.Text = "Edition :"
        '
        'lbl_Price
        '
        Me.lbl_Price.AutoSize = True
        Me.lbl_Price.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Price.Location = New System.Drawing.Point(16, 197)
        Me.lbl_Price.Name = "lbl_Price"
        Me.lbl_Price.Size = New System.Drawing.Size(40, 17)
        Me.lbl_Price.TabIndex = 4
        Me.lbl_Price.Text = "Price :"
        '
        'txt_bookid
        '
        Me.txt_bookid.Location = New System.Drawing.Point(104, 37)
        Me.txt_bookid.MaxLength = 6
        Me.txt_bookid.Name = "txt_bookid"
        Me.txt_bookid.Size = New System.Drawing.Size(160, 21)
        Me.txt_bookid.TabIndex = 0
        Me.txt_bookid.Text = ""
        '
        'txt_booktitle
        '
        Me.txt_booktitle.Location = New System.Drawing.Point(104, 77)
        Me.txt_booktitle.MaxLength = 50
        Me.txt_booktitle.Name = "txt_booktitle"
        Me.txt_booktitle.Size = New System.Drawing.Size(160, 21)
        Me.txt_booktitle.TabIndex = 1
        Me.txt_booktitle.Text = ""
        '
        'txt_author
        '
        Me.txt_author.Location = New System.Drawing.Point(104, 117)
        Me.txt_author.MaxLength = 30
        Me.txt_author.Name = "txt_author"
        Me.txt_author.Size = New System.Drawing.Size(160, 21)
        Me.txt_author.TabIndex = 2
        Me.txt_author.Text = ""
        '
        'txt_pub
        '
        Me.txt_pub.Location = New System.Drawing.Point(104, 157)
        Me.txt_pub.MaxLength = 50
        Me.txt_pub.Name = "txt_pub"
        Me.txt_pub.Size = New System.Drawing.Size(160, 21)
        Me.txt_pub.TabIndex = 3
        Me.txt_pub.Text = ""
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(104, 197)
        Me.txt_price.MaxLength = 4
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(160, 21)
        Me.txt_price.TabIndex = 4
        Me.txt_price.Text = ""
        '
        'dg_books
        '
        Me.dg_books.AlternatingBackColor = System.Drawing.Color.LightGray
        Me.dg_books.BackColor = System.Drawing.Color.Gainsboro
        Me.dg_books.BackgroundColor = System.Drawing.Color.Silver
        Me.dg_books.CaptionBackColor = System.Drawing.Color.LightSteelBlue
        Me.dg_books.CaptionForeColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.CaptionText = "Showing All Books"
        Me.dg_books.DataMember = ""
        Me.dg_books.FlatMode = True
        Me.dg_books.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dg_books.ForeColor = System.Drawing.Color.Black
        Me.dg_books.GridLineColor = System.Drawing.Color.White
        Me.dg_books.HeaderBackColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.HeaderFont = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.dg_books.HeaderForeColor = System.Drawing.Color.White
        Me.dg_books.LinkColor = System.Drawing.Color.MidnightBlue
        Me.dg_books.Location = New System.Drawing.Point(304, 40)
        Me.dg_books.Name = "dg_books"
        Me.dg_books.ParentRowsBackColor = System.Drawing.Color.DarkGray
        Me.dg_books.ParentRowsForeColor = System.Drawing.Color.Black
        Me.dg_books.ReadOnly = True
        Me.dg_books.SelectionBackColor = System.Drawing.Color.CadetBlue
        Me.dg_books.SelectionForeColor = System.Drawing.Color.White
        Me.dg_books.Size = New System.Drawing.Size(416, 280)
        Me.dg_books.TabIndex = 8
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btn_add)
        Me.GroupBox1.Controls.Add(Me.btn_remove)
        Me.GroupBox1.Controls.Add(Me.lbl_Price)
        Me.GroupBox1.Controls.Add(Me.txt_price)
        Me.GroupBox1.Controls.Add(Me.lbl_pub)
        Me.GroupBox1.Controls.Add(Me.txt_pub)
        Me.GroupBox1.Controls.Add(Me.lbl_author)
        Me.GroupBox1.Controls.Add(Me.txt_author)
        Me.GroupBox1.Controls.Add(Me.lbl_title)
        Me.GroupBox1.Controls.Add(Me.txt_booktitle)
        Me.GroupBox1.Controls.Add(Me.lbl_bookid)
        Me.GroupBox1.Controls.Add(Me.txt_bookid)
        Me.GroupBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(16, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 288)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Books Details"
        '
        'btn_add
        '
        Me.btn_add.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_add.ForeColor = System.Drawing.Color.Brown
        Me.btn_add.Location = New System.Drawing.Point(56, 234)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.Size = New System.Drawing.Size(72, 23)
        Me.btn_add.TabIndex = 5
        Me.btn_add.Text = "&Add"
        '
        'btn_remove
        '
        Me.btn_remove.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btn_remove.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_remove.ForeColor = System.Drawing.Color.Brown
        Me.btn_remove.Location = New System.Drawing.Point(144, 234)
        Me.btn_remove.Name = "btn_remove"
        Me.btn_remove.TabIndex = 6
        Me.btn_remove.Text = "&Remove"
        '
        'btn_close
        '
        Me.btn_close.Font = New System.Drawing.Font("Tahoma", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_close.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_close.Location = New System.Drawing.Point(712, 480)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(72, 24)
        Me.btn_close.TabIndex = 7
        Me.btn_close.Text = "Close"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(304, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Select the book record :"
        '
        'books
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.ClientSize = New System.Drawing.Size(722, 334)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_close)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.dg_books)
        Me.ForeColor = System.Drawing.Color.Navy
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "books"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add/Remove Books"
        CType(Me.dg_books, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand
    Dim dv As DataView
    Dim ch As Char
    Dim i As Integer
    Dim s As Integer


    Private Sub books_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            conn.Open() 'opening connection
            fillgrid() 'filling book data in grid

        Catch ex As OleDbException
            MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
            conn.Close()

        Finally
            GroupBox1.Focus()
            txt_bookid.Focus()
        End Try
    End Sub

    'method to fetch books info and display it in the grid
    Sub fillgrid()

        Try

            da = New OleDbDataAdapter("select * from tblbookinfo", conn)
            ds = New DataSet
            da.Fill(ds, "tblbookinfo")
            dv = New DataView(ds.Tables(0))
            dv.Sort = "bookid"
            dg_books.DataSource = dv


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Catch err As System.Exception
            MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Finally

            'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing

        End Try

    End Sub

    Private Sub btn_add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_add.Click
        Try
            If txt_bookid.Text <> "" AndAlso txt_booktitle.Text <> "" AndAlso txt_author.Text <> "" AndAlso txt_pub.Text <> "" AndAlso txt_price.Text <> "" Then
                cmd = New OleDbCommand
                cmd.Connection = conn
                conn.Close()
                conn.Open()
                cmd.CommandText = "insert into tblbookinfo values('" & txt_bookid.Text & "','" & txt_booktitle.Text & "','" & txt_author.Text & "','" & txt_price.Text & "'," & txt_pub.Text & ")"
                cmd.ExecuteNonQuery()
                MsgBox("Book record added successfully!!", MsgBoxStyle.Information)
                fillgrid()
                clearfields()

            Else 'one or more fields is blank

                MessageBox.Show("All fields are mandatory to fill.", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txt_bookid.Focus()

            End If

        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
            txt_bookid.Focus()

        Catch err As System.Exception
            MsgBox(err.Message, MessageBoxIcon.Error)
            txt_bookid.Focus()

        Finally

            cmd = Nothing
            conn.Close()
        End Try

    End Sub
    Sub cleardatabind()

        txt_bookid.DataBindings.Clear()
        txt_booktitle.DataBindings.Clear()
        txt_author.DataBindings.Clear()
        txt_pub.DataBindings.Clear()
        txt_price.DataBindings.Clear()


    End Sub
    Sub clearfields()
        txt_bookid.Clear()
        txt_booktitle.Clear()
        txt_author.Clear()
        txt_pub.Clear()
        txt_price.Clear()
        txt_bookid.Focus()
    End Sub

    Sub clear_stud_labels()
        'lbl_pname.Text = ""
        'lbl_pyear.Text = ""
        'lbl_pbranch.Text = ""
    End Sub

    Sub clear_stud_databind()
        'lbl_pname.DataBindings.Clear()
        'lbl_pyear.DataBindings.Clear()
        'lbl_pbranch.DataBindings.Clear()
    End Sub


    Private Sub txt_bookid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_bookid.KeyPress

        ch = e.KeyChar
        If ch.IsSymbol(ch) Or ch.IsPunctuation(ch) Then
            e.Handled = True
            MsgBox("Symbols are not allowed.", MessageBoxIcon.Stop)
        End If


        If Asc(e.KeyChar) = Keys.Enter Then
            'fill_on_keypress()

        End If

    End Sub

    Private Sub btn_remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_remove.Click

        Try

            '  If txt_bookid.Text <> "" AndAlso txt_booktitle.Text <> "" Then

            If dg_books.CurrentRowIndex = Nothing And dg_books.CurrentRowIndex <> 0 Then
                MsgBox("Please Select a Row then Click Remove Button!!!", MsgBoxStyle.Information)
            Else
                Dim i As Integer
                Dim s As String
                i = dg_books.CurrentRowIndex
                cmd = New OleDbCommand("Select count(*) from tbltransaction where bookid = '" & dg_books.Item(i, 0) & "'", conn)
                conn.Close()
                conn.Open()
                s = cmd.ExecuteScalar
                If s > 0 Then
                    MsgBox("Can not delete the book record because this book is issued.", MessageBoxIcon.Information)
                Else
                    cmd = New OleDbCommand
                    cmd.Connection = conn
                    conn.Close()
                    conn.Open()
                    cmd.CommandText = "delete from tblbookinfo where bookid='" & dg_books.Item(i, 0) & "'"
                    s = cmd.ExecuteNonQuery
                    If s > 0 Then
                        MsgBox("Book record deleted successfully", MessageBoxIcon.Information)
                        fillgrid()
                        clearfields()
                        'deleting the record
                    End If
                End If
            End If
            'txt_bookid.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)
        Finally
            cmd = Nothing
            conn.Close()
        End Try
    End Sub

    'Sub get_from_grid()
    '    Try
    '        i = dg_books.CurrentRowIndex
    '        txt_bookid.Text = dg_books.Item(i, 0)
    '        txt_booktitle.Text = dg_books.Item(i, 1)
    '        txt_author.Text = dg_books.Item(i, 2)
    '        txt_price.Text = dg_books.Item(i, 3)
    '        txt_pub.Text = dg_books.Item(i, 4)
    '        'get_student_info()

    '    Catch err As Exception
    '        MsgBox(err.Message)
    '    End Try
    'End Sub

    Private Sub dg_books_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_books.Click
        'get_from_grid()
    End Sub

    Private Sub dg_books_CurrentCellChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dg_books.CurrentCellChanged
        ' get_from_grid()
    End Sub


    Sub get_student_info()

        'Try
        '    clear_stud_databind()
        '    da = New SqlDataAdapter("select * from stud_info where S_Id=(select S_id from trans where Book_Id='" & txt_bookid.Text & "')", cn)
        '    ds = New DataSet
        '    da.Fill(ds, "stud_info")

        '    If ds.Tables(0).Rows.Count <> 0 Then

        '        dv = New DataView(ds.Tables(0))

        '        'binding data to the labels
        '        lbl_pname.DataBindings.Add("Text", dv, "Name")
        '        lbl_pyear.DataBindings.Add("Text", dv, "A_year")
        '        lbl_pbranch.DataBindings.Add("Text", dv, "Branch")

        '    Else

        '        clear_stud_labels()

        '    End If

        'Catch ex As SqlException
        '    MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

        'Catch err As System.Exception
        '    MessageBox.Show(err.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)

        'Finally

        '    'dereferencing objects
        '    da = Nothing
        '    ds = Nothing
        '    dv = Nothing

        'End Try


    End Sub


    Private Sub btn_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_close.Click
        Me.Close()
    End Sub

    Private Sub books_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        conn.Close()
    End Sub

    Private Sub txt_price_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txt_price.KeyPress

        ch = e.KeyChar

        If Not (ch.IsDigit(ch) Or Asc(e.KeyChar) = Keys.Back) Then
            e.Handled = True
        End If

    End Sub

    Sub fill_on_keypress()
        Try
            cleardatabind()
            da = New OleDbDataAdapter("select * from tblbookinfo where bookid='" & txt_bookid.Text & "'", conn)
            ds = New DataSet
            da.Fill(ds, "tblbookinfo")
            If ds.Tables("tblbookinfo").Rows.Count <> 0 Then 'no rows selected
                dv = New DataView(ds.Tables(0))
                txt_booktitle.DataBindings.Add("Text", dv, "booktitle")
                txt_author.DataBindings.Add("Text", dv, "bookauthor")
                txt_pub.DataBindings.Add("Text", dv, "bookedition")
                txt_price.DataBindings.Add("Text", dv, "bookprice")
                'displaying student info
                '                get_student_info()
            Else
                txt_booktitle.Clear()
                txt_author.Clear()
                txt_pub.Clear()
                txt_price.Clear()
                clear_stud_labels()
                '  txt_bookid.Focus()
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MessageBoxIcon.Error)

        Finally

            'dereferencing objects
            da = Nothing
            ds = Nothing
            dv = Nothing

        End Try

    End Sub


    Private Sub txt_bookid_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_bookid.LostFocus
        'If txt_bookid.Text <> "" Then
        ' fill_on_keypress()
        'End If
    End Sub

    Private Sub lbl_help_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ' MessageBox.Show("You will have to delete the record to be updated and insert it again with the new information.", "LMS Help", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub dg_books_Navigate(ByVal sender As System.Object, ByVal ne As System.Windows.Forms.NavigateEventArgs) Handles dg_books.Navigate

    End Sub
End Class
